﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NearLossless
{
    public static class Constants
    {
        public const int ImageSize = 256;
        public const int HeaderSize = 1078;
        public const int HistogramSize = 512;
        public const int SaveingPicturePixelSize = 9;
        public const int BmpHeaderBitCount = 8;
        public const int KHeaderBitCount = 4;
        public const int PredictorHeaderBitCount = 4;
        public const int SavingTypeHeaderBitCount = 2;
    }
}
