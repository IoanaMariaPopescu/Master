﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NearLossless
{
    public class BitReader
    {
        FileStream fs;
        byte buffer;
        byte counter;
        public BitReader(string path)
        {
            fs = new FileStream(path, FileMode.Open);
        }

        public void Close()
        {
            fs.Close();
        }

        public int ReadBit()
        {
            if (counter == 8)
                counter = 0;

            if(counter==0)
            {
                int val = fs.ReadByte();
                if (val == -1)
                    return -1;
                buffer = (byte)val;
                counter++;
                return (buffer >> 7) & 1;
            }
            counter++;
            return (buffer >> (8 - counter)) & 1;
            //citesc un byte , returnez cate 1 bit din buffer pana ajunge la 8 ( se goleste bufferu)
            //apoi resetez contorul si mai citesc un byte
            //fs.readbyte
        }

        public long ReadNBits(int n)
        {
            uint val = 0;
            for(int i=0;i<n;i++)
            {
                val <<= 1;
                long value = ReadBit();
                if (value == -1)
                    return -1;
                val += (uint)value;
            }
            return val;
            //for pana la n
            //shiftez cate 1 bit si apoi apelez readbit si il pun in variabila
        }
    }

}
