﻿
namespace NearLossless
{
    partial class NearLosslessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.saveOriginalButton = new System.Windows.Forms.Button();
            this.encodeButton = new System.Windows.Forms.Button();
            this.loadOriginalButton = new System.Windows.Forms.Button();
            this.originalPictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.refreshErrorImageButton = new System.Windows.Forms.Button();
            this.contrastNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.predictionErrorRadioButton = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.qPredictionErrorRadioButton = new System.Windows.Forms.RadioButton();
            this.errorPictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.saveDecodedButton = new System.Windows.Forms.Button();
            this.decodeButton = new System.Windows.Forms.Button();
            this.loadEncodedButton = new System.Windows.Forms.Button();
            this.decodedPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.kNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.p128RadioButton = new System.Windows.Forms.RadioButton();
            this.jpeglsRadioButton = new System.Windows.Forms.RadioButton();
            this.ApBd2RadioButton = new System.Windows.Forms.RadioButton();
            this.BpAmCd2RadioButton = new System.Windows.Forms.RadioButton();
            this.pApBmCd2RadioButton6 = new System.Windows.Forms.RadioButton();
            this.pApBmCRadioButton = new System.Windows.Forms.RadioButton();
            this.pCRadioButton = new System.Windows.Forms.RadioButton();
            this.pBRadioButton = new System.Windows.Forms.RadioButton();
            this.pARadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.fixedRadioButton = new System.Windows.Forms.RadioButton();
            this.arithmeticRadioButton = new System.Windows.Forms.RadioButton();
            this.tableRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.maxErrorTextBox = new System.Windows.Forms.TextBox();
            this.minErrorTextBox = new System.Windows.Forms.TextBox();
            this.computeErrorButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.refreshHistogramButton = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.histOriginalRadioButton = new System.Windows.Forms.RadioButton();
            this.histDecoderQPredRadioButton = new System.Windows.Forms.RadioButton();
            this.histCoderQPredRadioButton = new System.Windows.Forms.RadioButton();
            this.histDecoderPredRadioButton = new System.Windows.Forms.RadioButton();
            this.histCoderPredRadioButton = new System.Windows.Forms.RadioButton();
            this.histDecoderDecodedRadioButton = new System.Windows.Forms.RadioButton();
            this.histCoderDecodedRadioButton = new System.Windows.Forms.RadioButton();
            this.histScaleNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.histogramPictureBox = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.scaleTrackBar = new System.Windows.Forms.TrackBar();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalPictureBox)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contrastNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPictureBox)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.decodedPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kNumericUpDown)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.histScaleNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.histogramPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.saveOriginalButton);
            this.groupBox1.Controls.Add(this.encodeButton);
            this.groupBox1.Controls.Add(this.loadOriginalButton);
            this.groupBox1.Controls.Add(this.originalPictureBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(269, 345);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Original Image";
            // 
            // saveOriginalButton
            // 
            this.saveOriginalButton.Location = new System.Drawing.Point(6, 316);
            this.saveOriginalButton.Name = "saveOriginalButton";
            this.saveOriginalButton.Size = new System.Drawing.Size(75, 23);
            this.saveOriginalButton.TabIndex = 3;
            this.saveOriginalButton.Text = "Save";
            this.saveOriginalButton.UseVisualStyleBackColor = true;
            this.saveOriginalButton.Click += new System.EventHandler(this.saveOriginalButton_Click);
            // 
            // encodeButton
            // 
            this.encodeButton.Location = new System.Drawing.Point(187, 280);
            this.encodeButton.Name = "encodeButton";
            this.encodeButton.Size = new System.Drawing.Size(75, 23);
            this.encodeButton.TabIndex = 2;
            this.encodeButton.Text = "Encode";
            this.encodeButton.UseVisualStyleBackColor = true;
            this.encodeButton.Click += new System.EventHandler(this.encodeButton_Click);
            // 
            // loadOriginalButton
            // 
            this.loadOriginalButton.Location = new System.Drawing.Point(6, 282);
            this.loadOriginalButton.Name = "loadOriginalButton";
            this.loadOriginalButton.Size = new System.Drawing.Size(75, 23);
            this.loadOriginalButton.TabIndex = 1;
            this.loadOriginalButton.Text = "Load";
            this.loadOriginalButton.UseVisualStyleBackColor = true;
            this.loadOriginalButton.Click += new System.EventHandler(this.loadOriginalButton_Click);
            // 
            // originalPictureBox
            // 
            this.originalPictureBox.Location = new System.Drawing.Point(6, 19);
            this.originalPictureBox.Name = "originalPictureBox";
            this.originalPictureBox.Size = new System.Drawing.Size(256, 256);
            this.originalPictureBox.TabIndex = 0;
            this.originalPictureBox.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.refreshErrorImageButton);
            this.groupBox2.Controls.Add(this.contrastNumericUpDown);
            this.groupBox2.Controls.Add(this.predictionErrorRadioButton);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.qPredictionErrorRadioButton);
            this.groupBox2.Controls.Add(this.errorPictureBox);
            this.groupBox2.Location = new System.Drawing.Point(375, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(269, 345);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Error Image";
            // 
            // refreshErrorImageButton
            // 
            this.refreshErrorImageButton.Location = new System.Drawing.Point(186, 314);
            this.refreshErrorImageButton.Name = "refreshErrorImageButton";
            this.refreshErrorImageButton.Size = new System.Drawing.Size(75, 23);
            this.refreshErrorImageButton.TabIndex = 3;
            this.refreshErrorImageButton.Text = "Refresh";
            this.refreshErrorImageButton.UseVisualStyleBackColor = true;
            this.refreshErrorImageButton.Click += new System.EventHandler(this.refreshErrorImageButton_Click);
            // 
            // contrastNumericUpDown
            // 
            this.contrastNumericUpDown.DecimalPlaces = 1;
            this.contrastNumericUpDown.Location = new System.Drawing.Point(208, 281);
            this.contrastNumericUpDown.Name = "contrastNumericUpDown";
            this.contrastNumericUpDown.Size = new System.Drawing.Size(53, 20);
            this.contrastNumericUpDown.TabIndex = 4;
            this.contrastNumericUpDown.Value = new decimal(new int[] {
            123,
            0,
            0,
            65536});
            // 
            // predictionErrorRadioButton
            // 
            this.predictionErrorRadioButton.AutoSize = true;
            this.predictionErrorRadioButton.Checked = true;
            this.predictionErrorRadioButton.Location = new System.Drawing.Point(6, 288);
            this.predictionErrorRadioButton.Name = "predictionErrorRadioButton";
            this.predictionErrorRadioButton.Size = new System.Drawing.Size(97, 17);
            this.predictionErrorRadioButton.TabIndex = 2;
            this.predictionErrorRadioButton.TabStop = true;
            this.predictionErrorRadioButton.Text = "Prediction Error";
            this.predictionErrorRadioButton.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(153, 283);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Contrast:";
            // 
            // qPredictionErrorRadioButton
            // 
            this.qPredictionErrorRadioButton.AutoSize = true;
            this.qPredictionErrorRadioButton.Location = new System.Drawing.Point(6, 311);
            this.qPredictionErrorRadioButton.Name = "qPredictionErrorRadioButton";
            this.qPredictionErrorRadioButton.Size = new System.Drawing.Size(108, 17);
            this.qPredictionErrorRadioButton.TabIndex = 1;
            this.qPredictionErrorRadioButton.Text = "Q Prediction Error";
            this.qPredictionErrorRadioButton.UseVisualStyleBackColor = true;
            // 
            // errorPictureBox
            // 
            this.errorPictureBox.Location = new System.Drawing.Point(6, 19);
            this.errorPictureBox.Name = "errorPictureBox";
            this.errorPictureBox.Size = new System.Drawing.Size(256, 256);
            this.errorPictureBox.TabIndex = 0;
            this.errorPictureBox.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.saveDecodedButton);
            this.groupBox3.Controls.Add(this.decodeButton);
            this.groupBox3.Controls.Add(this.loadEncodedButton);
            this.groupBox3.Controls.Add(this.decodedPictureBox);
            this.groupBox3.Location = new System.Drawing.Point(772, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(269, 345);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Decoded Image";
            // 
            // saveDecodedButton
            // 
            this.saveDecodedButton.Location = new System.Drawing.Point(6, 316);
            this.saveDecodedButton.Name = "saveDecodedButton";
            this.saveDecodedButton.Size = new System.Drawing.Size(75, 23);
            this.saveDecodedButton.TabIndex = 4;
            this.saveDecodedButton.Text = "Save";
            this.saveDecodedButton.UseVisualStyleBackColor = true;
            this.saveDecodedButton.Click += new System.EventHandler(this.saveDecodedButton_Click);
            // 
            // decodeButton
            // 
            this.decodeButton.Location = new System.Drawing.Point(187, 282);
            this.decodeButton.Name = "decodeButton";
            this.decodeButton.Size = new System.Drawing.Size(75, 23);
            this.decodeButton.TabIndex = 4;
            this.decodeButton.Text = "Decode";
            this.decodeButton.UseVisualStyleBackColor = true;
            this.decodeButton.Click += new System.EventHandler(this.decodeButton_Click);
            // 
            // loadEncodedButton
            // 
            this.loadEncodedButton.Location = new System.Drawing.Point(6, 282);
            this.loadEncodedButton.Name = "loadEncodedButton";
            this.loadEncodedButton.Size = new System.Drawing.Size(75, 23);
            this.loadEncodedButton.TabIndex = 4;
            this.loadEncodedButton.Text = "Load";
            this.loadEncodedButton.UseVisualStyleBackColor = true;
            this.loadEncodedButton.Click += new System.EventHandler(this.loadEncodedButton_Click);
            // 
            // decodedPictureBox
            // 
            this.decodedPictureBox.Location = new System.Drawing.Point(6, 19);
            this.decodedPictureBox.Name = "decodedPictureBox";
            this.decodedPictureBox.Size = new System.Drawing.Size(256, 256);
            this.decodedPictureBox.TabIndex = 0;
            this.decodedPictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "K Value";
            // 
            // kNumericUpDown
            // 
            this.kNumericUpDown.Location = new System.Drawing.Point(92, 62);
            this.kNumericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.kNumericUpDown.Name = "kNumericUpDown";
            this.kNumericUpDown.Size = new System.Drawing.Size(41, 20);
            this.kNumericUpDown.TabIndex = 4;
            this.kNumericUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.p128RadioButton);
            this.groupBox4.Controls.Add(this.kNumericUpDown);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.jpeglsRadioButton);
            this.groupBox4.Controls.Add(this.ApBd2RadioButton);
            this.groupBox4.Controls.Add(this.BpAmCd2RadioButton);
            this.groupBox4.Controls.Add(this.pApBmCd2RadioButton6);
            this.groupBox4.Controls.Add(this.pApBmCRadioButton);
            this.groupBox4.Controls.Add(this.pCRadioButton);
            this.groupBox4.Controls.Add(this.pBRadioButton);
            this.groupBox4.Controls.Add(this.pARadioButton);
            this.groupBox4.Location = new System.Drawing.Point(12, 378);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(138, 240);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Predictor Type";
            // 
            // p128RadioButton
            // 
            this.p128RadioButton.AutoSize = true;
            this.p128RadioButton.Checked = true;
            this.p128RadioButton.Location = new System.Drawing.Point(6, 19);
            this.p128RadioButton.Name = "p128RadioButton";
            this.p128RadioButton.Size = new System.Drawing.Size(43, 17);
            this.p128RadioButton.TabIndex = 2;
            this.p128RadioButton.TabStop = true;
            this.p128RadioButton.Text = "128";
            this.p128RadioButton.UseVisualStyleBackColor = true;
            this.p128RadioButton.Click += new System.EventHandler(this.p128RadioButton_CheckedChanged);
            // 
            // jpeglsRadioButton
            // 
            this.jpeglsRadioButton.AutoSize = true;
            this.jpeglsRadioButton.Location = new System.Drawing.Point(6, 203);
            this.jpeglsRadioButton.Name = "jpeglsRadioButton";
            this.jpeglsRadioButton.Size = new System.Drawing.Size(68, 17);
            this.jpeglsRadioButton.TabIndex = 1;
            this.jpeglsRadioButton.Text = "JPEG-LS";
            this.jpeglsRadioButton.UseVisualStyleBackColor = true;
            this.jpeglsRadioButton.Click += new System.EventHandler(this.jpeglsRadioButton_CheckedChanged);
            // 
            // ApBd2RadioButton
            // 
            this.ApBd2RadioButton.AutoSize = true;
            this.ApBd2RadioButton.Location = new System.Drawing.Point(6, 180);
            this.ApBd2RadioButton.Name = "ApBd2RadioButton";
            this.ApBd2RadioButton.Size = new System.Drawing.Size(74, 17);
            this.ApBd2RadioButton.TabIndex = 1;
            this.ApBd2RadioButton.Text = "(A + B) / 2";
            this.ApBd2RadioButton.UseVisualStyleBackColor = true;
            this.ApBd2RadioButton.Click += new System.EventHandler(this.ApBd2RadioButton_CheckedChanged);
            // 
            // BpAmCd2RadioButton
            // 
            this.BpAmCd2RadioButton.AutoSize = true;
            this.BpAmCd2RadioButton.Location = new System.Drawing.Point(6, 157);
            this.BpAmCd2RadioButton.Name = "BpAmCd2RadioButton";
            this.BpAmCd2RadioButton.Size = new System.Drawing.Size(90, 17);
            this.BpAmCd2RadioButton.TabIndex = 1;
            this.BpAmCd2RadioButton.Text = "B + (A - C) / 2";
            this.BpAmCd2RadioButton.UseVisualStyleBackColor = true;
            this.BpAmCd2RadioButton.Click += new System.EventHandler(this.BpAmCd2RadioButton_CheckedChanged);
            // 
            // pApBmCd2RadioButton6
            // 
            this.pApBmCd2RadioButton6.AutoSize = true;
            this.pApBmCd2RadioButton6.Location = new System.Drawing.Point(6, 134);
            this.pApBmCd2RadioButton6.Name = "pApBmCd2RadioButton6";
            this.pApBmCd2RadioButton6.Size = new System.Drawing.Size(93, 17);
            this.pApBmCd2RadioButton6.TabIndex = 1;
            this.pApBmCd2RadioButton6.Text = "A + (B - C)  / 2";
            this.pApBmCd2RadioButton6.UseVisualStyleBackColor = true;
            this.pApBmCd2RadioButton6.Click += new System.EventHandler(this.pApBmCd2RadioButton6_CheckedChanged);
            // 
            // pApBmCRadioButton
            // 
            this.pApBmCRadioButton.AutoSize = true;
            this.pApBmCRadioButton.Location = new System.Drawing.Point(6, 111);
            this.pApBmCRadioButton.Name = "pApBmCRadioButton";
            this.pApBmCRadioButton.Size = new System.Drawing.Size(67, 17);
            this.pApBmCRadioButton.TabIndex = 1;
            this.pApBmCRadioButton.Text = "A + B - C";
            this.pApBmCRadioButton.UseVisualStyleBackColor = true;
            this.pApBmCRadioButton.Click += new System.EventHandler(this.pApBmCRadioButton_CheckedChanged);
            // 
            // pCRadioButton
            // 
            this.pCRadioButton.AutoSize = true;
            this.pCRadioButton.Location = new System.Drawing.Point(6, 88);
            this.pCRadioButton.Name = "pCRadioButton";
            this.pCRadioButton.Size = new System.Drawing.Size(32, 17);
            this.pCRadioButton.TabIndex = 1;
            this.pCRadioButton.Text = "C";
            this.pCRadioButton.UseVisualStyleBackColor = true;
            this.pCRadioButton.Click += new System.EventHandler(this.pCRadioButton_CheckedChanged);
            // 
            // pBRadioButton
            // 
            this.pBRadioButton.AutoSize = true;
            this.pBRadioButton.Location = new System.Drawing.Point(6, 65);
            this.pBRadioButton.Name = "pBRadioButton";
            this.pBRadioButton.Size = new System.Drawing.Size(32, 17);
            this.pBRadioButton.TabIndex = 1;
            this.pBRadioButton.Text = "B";
            this.pBRadioButton.UseVisualStyleBackColor = true;
            this.pBRadioButton.Click += new System.EventHandler(this.pBRadioButton_CheckedChanged);
            // 
            // pARadioButton
            // 
            this.pARadioButton.AutoSize = true;
            this.pARadioButton.Location = new System.Drawing.Point(6, 42);
            this.pARadioButton.Name = "pARadioButton";
            this.pARadioButton.Size = new System.Drawing.Size(32, 17);
            this.pARadioButton.TabIndex = 1;
            this.pARadioButton.Text = "A";
            this.pARadioButton.UseVisualStyleBackColor = true;
            this.pARadioButton.Click += new System.EventHandler(this.pARadioButton_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.fixedRadioButton);
            this.groupBox5.Controls.Add(this.arithmeticRadioButton);
            this.groupBox5.Controls.Add(this.tableRadioButton);
            this.groupBox5.Location = new System.Drawing.Point(159, 378);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(105, 93);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Saving mode";
            // 
            // fixedRadioButton
            // 
            this.fixedRadioButton.AutoSize = true;
            this.fixedRadioButton.Checked = true;
            this.fixedRadioButton.Location = new System.Drawing.Point(6, 19);
            this.fixedRadioButton.Name = "fixedRadioButton";
            this.fixedRadioButton.Size = new System.Drawing.Size(50, 17);
            this.fixedRadioButton.TabIndex = 2;
            this.fixedRadioButton.TabStop = true;
            this.fixedRadioButton.Text = "Fixed";
            this.fixedRadioButton.UseVisualStyleBackColor = true;
            // 
            // arithmeticRadioButton
            // 
            this.arithmeticRadioButton.AutoSize = true;
            this.arithmeticRadioButton.Enabled = false;
            this.arithmeticRadioButton.Location = new System.Drawing.Point(6, 65);
            this.arithmeticRadioButton.Name = "arithmeticRadioButton";
            this.arithmeticRadioButton.Size = new System.Drawing.Size(71, 17);
            this.arithmeticRadioButton.TabIndex = 1;
            this.arithmeticRadioButton.Text = "Arithmetic";
            this.arithmeticRadioButton.UseVisualStyleBackColor = true;
            // 
            // tableRadioButton
            // 
            this.tableRadioButton.AutoSize = true;
            this.tableRadioButton.Location = new System.Drawing.Point(6, 42);
            this.tableRadioButton.Name = "tableRadioButton";
            this.tableRadioButton.Size = new System.Drawing.Size(52, 17);
            this.tableRadioButton.TabIndex = 1;
            this.tableRadioButton.Text = "Table";
            this.tableRadioButton.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.maxErrorTextBox);
            this.groupBox6.Controls.Add(this.minErrorTextBox);
            this.groupBox6.Controls.Add(this.computeErrorButton);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Location = new System.Drawing.Point(159, 489);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(105, 129);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Error";
            // 
            // maxErrorTextBox
            // 
            this.maxErrorTextBox.Enabled = false;
            this.maxErrorTextBox.Location = new System.Drawing.Point(39, 76);
            this.maxErrorTextBox.Name = "maxErrorTextBox";
            this.maxErrorTextBox.Size = new System.Drawing.Size(47, 20);
            this.maxErrorTextBox.TabIndex = 4;
            // 
            // minErrorTextBox
            // 
            this.minErrorTextBox.Enabled = false;
            this.minErrorTextBox.Location = new System.Drawing.Point(39, 50);
            this.minErrorTextBox.Name = "minErrorTextBox";
            this.minErrorTextBox.Size = new System.Drawing.Size(47, 20);
            this.minErrorTextBox.TabIndex = 4;
            // 
            // computeErrorButton
            // 
            this.computeErrorButton.Location = new System.Drawing.Point(6, 17);
            this.computeErrorButton.Name = "computeErrorButton";
            this.computeErrorButton.Size = new System.Drawing.Size(93, 23);
            this.computeErrorButton.TabIndex = 3;
            this.computeErrorButton.Text = "Compute Error";
            this.computeErrorButton.UseVisualStyleBackColor = true;
            this.computeErrorButton.Click += new System.EventHandler(this.computeErrorButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Max:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Min:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.scaleTrackBar);
            this.groupBox7.Controls.Add(this.refreshHistogramButton);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.histScaleNumericUpDown);
            this.groupBox7.Controls.Add(this.histogramPictureBox);
            this.groupBox7.Controls.Add(this.label4);
            this.groupBox7.Location = new System.Drawing.Point(272, 378);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(751, 240);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Histogram";
            // 
            // refreshHistogramButton
            // 
            this.refreshHistogramButton.Location = new System.Drawing.Point(114, 208);
            this.refreshHistogramButton.Name = "refreshHistogramButton";
            this.refreshHistogramButton.Size = new System.Drawing.Size(55, 23);
            this.refreshHistogramButton.TabIndex = 3;
            this.refreshHistogramButton.Text = "Refresh";
            this.refreshHistogramButton.UseVisualStyleBackColor = true;
            this.refreshHistogramButton.Click += new System.EventHandler(this.refreshHistogramButton_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.histOriginalRadioButton);
            this.groupBox8.Controls.Add(this.histDecoderQPredRadioButton);
            this.groupBox8.Controls.Add(this.histCoderQPredRadioButton);
            this.groupBox8.Controls.Add(this.histDecoderPredRadioButton);
            this.groupBox8.Controls.Add(this.histCoderPredRadioButton);
            this.groupBox8.Controls.Add(this.histDecoderDecodedRadioButton);
            this.groupBox8.Controls.Add(this.histCoderDecodedRadioButton);
            this.groupBox8.Location = new System.Drawing.Point(7, 20);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(162, 187);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Source Image";
            // 
            // histOriginalRadioButton
            // 
            this.histOriginalRadioButton.AutoSize = true;
            this.histOriginalRadioButton.Checked = true;
            this.histOriginalRadioButton.Location = new System.Drawing.Point(6, 22);
            this.histOriginalRadioButton.Name = "histOriginalRadioButton";
            this.histOriginalRadioButton.Size = new System.Drawing.Size(60, 17);
            this.histOriginalRadioButton.TabIndex = 2;
            this.histOriginalRadioButton.TabStop = true;
            this.histOriginalRadioButton.Text = "Original";
            this.histOriginalRadioButton.UseVisualStyleBackColor = true;
            this.histOriginalRadioButton.Click += new System.EventHandler(this.histOriginalRadioButton_CheckedChanged);
            // 
            // histDecoderQPredRadioButton
            // 
            this.histDecoderQPredRadioButton.AutoSize = true;
            this.histDecoderQPredRadioButton.Location = new System.Drawing.Point(6, 137);
            this.histDecoderQPredRadioButton.Name = "histDecoderQPredRadioButton";
            this.histDecoderQPredRadioButton.Size = new System.Drawing.Size(152, 17);
            this.histDecoderQPredRadioButton.TabIndex = 1;
            this.histDecoderQPredRadioButton.Text = "Decoder Q Prediction Error";
            this.histDecoderQPredRadioButton.UseVisualStyleBackColor = true;
            this.histDecoderQPredRadioButton.Click += new System.EventHandler(this.histDecoderQPredRadioButton_CheckedChanged);
            // 
            // histCoderQPredRadioButton
            // 
            this.histCoderQPredRadioButton.AutoSize = true;
            this.histCoderQPredRadioButton.Location = new System.Drawing.Point(6, 68);
            this.histCoderQPredRadioButton.Name = "histCoderQPredRadioButton";
            this.histCoderQPredRadioButton.Size = new System.Drawing.Size(139, 17);
            this.histCoderQPredRadioButton.TabIndex = 1;
            this.histCoderQPredRadioButton.Text = "Coder Q Prediction Error";
            this.histCoderQPredRadioButton.UseVisualStyleBackColor = true;
            this.histCoderQPredRadioButton.Click += new System.EventHandler(this.histCoderQPredRadioButton_CheckedChanged);
            // 
            // histDecoderPredRadioButton
            // 
            this.histDecoderPredRadioButton.AutoSize = true;
            this.histDecoderPredRadioButton.Location = new System.Drawing.Point(6, 114);
            this.histDecoderPredRadioButton.Name = "histDecoderPredRadioButton";
            this.histDecoderPredRadioButton.Size = new System.Drawing.Size(141, 17);
            this.histDecoderPredRadioButton.TabIndex = 1;
            this.histDecoderPredRadioButton.Text = "Decoder Prediction Error";
            this.histDecoderPredRadioButton.UseVisualStyleBackColor = true;
            this.histDecoderPredRadioButton.Click += new System.EventHandler(this.histDecoderPredRadioButton_CheckedChanged);
            // 
            // histCoderPredRadioButton
            // 
            this.histCoderPredRadioButton.AutoSize = true;
            this.histCoderPredRadioButton.Location = new System.Drawing.Point(6, 45);
            this.histCoderPredRadioButton.Name = "histCoderPredRadioButton";
            this.histCoderPredRadioButton.Size = new System.Drawing.Size(128, 17);
            this.histCoderPredRadioButton.TabIndex = 1;
            this.histCoderPredRadioButton.Text = "Coder Prediction Error";
            this.histCoderPredRadioButton.UseVisualStyleBackColor = true;
            this.histCoderPredRadioButton.Click += new System.EventHandler(this.histCoderPredRadioButton_CheckedChanged);
            // 
            // histDecoderDecodedRadioButton
            // 
            this.histDecoderDecodedRadioButton.AutoSize = true;
            this.histDecoderDecodedRadioButton.Location = new System.Drawing.Point(6, 160);
            this.histDecoderDecodedRadioButton.Name = "histDecoderDecodedRadioButton";
            this.histDecoderDecodedRadioButton.Size = new System.Drawing.Size(113, 17);
            this.histDecoderDecodedRadioButton.TabIndex = 1;
            this.histDecoderDecodedRadioButton.Text = "Decoder Decoded";
            this.histDecoderDecodedRadioButton.UseVisualStyleBackColor = true;
            this.histDecoderDecodedRadioButton.Click += new System.EventHandler(this.histDecoderDecodedRadioButton_CheckedChanged);
            // 
            // histCoderDecodedRadioButton
            // 
            this.histCoderDecodedRadioButton.AutoSize = true;
            this.histCoderDecodedRadioButton.Location = new System.Drawing.Point(6, 91);
            this.histCoderDecodedRadioButton.Name = "histCoderDecodedRadioButton";
            this.histCoderDecodedRadioButton.Size = new System.Drawing.Size(100, 17);
            this.histCoderDecodedRadioButton.TabIndex = 1;
            this.histCoderDecodedRadioButton.Text = "Coder Decoded";
            this.histCoderDecodedRadioButton.UseVisualStyleBackColor = true;
            this.histCoderDecodedRadioButton.Click += new System.EventHandler(this.histCoderDecodedRadioButton_CheckedChanged);
            // 
            // histScaleNumericUpDown
            // 
            this.histScaleNumericUpDown.DecimalPlaces = 2;
            this.histScaleNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.histScaleNumericUpDown.Location = new System.Drawing.Point(41, 211);
            this.histScaleNumericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.histScaleNumericUpDown.Name = "histScaleNumericUpDown";
            this.histScaleNumericUpDown.Size = new System.Drawing.Size(59, 20);
            this.histScaleNumericUpDown.TabIndex = 4;
            this.histScaleNumericUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.histScaleNumericUpDown.ValueChanged += new System.EventHandler(this.histScaleNumericUpDown_ValueChanged);
            // 
            // histogramPictureBox
            // 
            this.histogramPictureBox.Location = new System.Drawing.Point(228, 16);
            this.histogramPictureBox.Name = "histogramPictureBox";
            this.histogramPictureBox.Size = new System.Drawing.Size(511, 218);
            this.histogramPictureBox.TabIndex = 0;
            this.histogramPictureBox.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Scale:";
            // 
            // scaleTrackBar
            // 
            this.scaleTrackBar.Location = new System.Drawing.Point(177, 16);
            this.scaleTrackBar.Maximum = 150;
            this.scaleTrackBar.Name = "scaleTrackBar";
            this.scaleTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.scaleTrackBar.Size = new System.Drawing.Size(45, 218);
            this.scaleTrackBar.SmallChange = 5;
            this.scaleTrackBar.TabIndex = 7;
            this.scaleTrackBar.Value = 20;
            this.scaleTrackBar.ValueChanged += new System.EventHandler(this.scaleTrackBar_ValueChanged);
            // 
            // NearLosslessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 639);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "NearLosslessForm";
            this.Text = "Near Lossless Prediction";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.originalPictureBox)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contrastNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPictureBox)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.decodedPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kNumericUpDown)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.histScaleNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.histogramPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleTrackBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button saveOriginalButton;
        private System.Windows.Forms.Button encodeButton;
        private System.Windows.Forms.Button loadOriginalButton;
        private System.Windows.Forms.PictureBox originalPictureBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button refreshErrorImageButton;
        private System.Windows.Forms.NumericUpDown kNumericUpDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton predictionErrorRadioButton;
        private System.Windows.Forms.RadioButton qPredictionErrorRadioButton;
        private System.Windows.Forms.PictureBox errorPictureBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button saveDecodedButton;
        private System.Windows.Forms.Button decodeButton;
        private System.Windows.Forms.Button loadEncodedButton;
        private System.Windows.Forms.PictureBox decodedPictureBox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton p128RadioButton;
        private System.Windows.Forms.RadioButton jpeglsRadioButton;
        private System.Windows.Forms.RadioButton ApBd2RadioButton;
        private System.Windows.Forms.RadioButton BpAmCd2RadioButton;
        private System.Windows.Forms.RadioButton pApBmCd2RadioButton6;
        private System.Windows.Forms.RadioButton pApBmCRadioButton;
        private System.Windows.Forms.RadioButton pCRadioButton;
        private System.Windows.Forms.RadioButton pBRadioButton;
        private System.Windows.Forms.RadioButton pARadioButton;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton fixedRadioButton;
        private System.Windows.Forms.RadioButton arithmeticRadioButton;
        private System.Windows.Forms.RadioButton tableRadioButton;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox maxErrorTextBox;
        private System.Windows.Forms.TextBox minErrorTextBox;
        private System.Windows.Forms.Button computeErrorButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton histOriginalRadioButton;
        private System.Windows.Forms.RadioButton histDecoderQPredRadioButton;
        private System.Windows.Forms.RadioButton histCoderQPredRadioButton;
        private System.Windows.Forms.RadioButton histDecoderPredRadioButton;
        private System.Windows.Forms.RadioButton histCoderPredRadioButton;
        private System.Windows.Forms.RadioButton histDecoderDecodedRadioButton;
        private System.Windows.Forms.RadioButton histCoderDecodedRadioButton;
        private System.Windows.Forms.PictureBox histogramPictureBox;
        private System.Windows.Forms.Button refreshHistogramButton;
        private System.Windows.Forms.NumericUpDown histScaleNumericUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown contrastNumericUpDown;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar scaleTrackBar;
    }
}

