﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static NearLossless.Constants;

namespace NearLossless
{
    public partial class NearLosslessForm : Form
    {
        byte[,] CoderOriginal;
        byte[,] CoderPrediction;
        int[,] CoderErrorPrediction;
        int[,] CoderErrorPredictionQ;
        int[,] CoderErrorPredictionDQ;
        byte[,] CoderPrediction2;
        byte[,] CoderDecoded;
        int[,] CoderError;

        byte[,] DecoderPrediction;
        int[,] DecoderErrorPrediction;
        int[,] DecoderErrorPredictionQ;
        int[,] DecoderErrorPredictionDQ;
        byte[,] DecoderDecoded;

        byte[] HeaderBytes;
        byte[,] HistogramImageMatrix;
        int[,] HistogramErrorMatrix;
        PredictorType Predictor;
        int DecoderK;
        string OpenedNlpFileName;

        public NearLosslessForm()
        {
            InitializeComponent();
            HeaderBytes = new byte[HeaderSize];
            CoderOriginal = new byte[ImageSize, ImageSize];
            Predictor = PredictorType.P128;
            CoderPrediction = new byte[ImageSize, ImageSize];
            CoderErrorPrediction = new int[ImageSize, ImageSize];
            CoderErrorPredictionQ = new int[ImageSize, ImageSize];
            CoderErrorPredictionDQ = new int[ImageSize, ImageSize];
            CoderPrediction2 = new byte[ImageSize, ImageSize];
            CoderDecoded = new byte[ImageSize, ImageSize];
            CoderError = new int[ImageSize, ImageSize];

            DecoderPrediction = new byte[ImageSize, ImageSize];
            DecoderErrorPrediction = new int[ImageSize, ImageSize];
            DecoderErrorPredictionQ = new int[ImageSize, ImageSize];
            DecoderErrorPredictionDQ = new int[ImageSize, ImageSize];
            DecoderDecoded = new byte[ImageSize, ImageSize];
        }

        private void loadOriginalButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Choose Picture";
            dialog.Filter = "BMP images|*.bmp";
            dialog.InitialDirectory = string.Format(@"{0}\Images", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                originalPictureBox.Image = new Bitmap(dialog.FileName);
                byte[] fileBytes = File.ReadAllBytes(dialog.FileName);
                for (int i = 0; i < HeaderSize; i++)
                {
                    HeaderBytes[i] = fileBytes[i];
                }

                for (int i = 0; i < ImageSize; i++)
                {
                    for (int j = 0; j < ImageSize; j++)
                    {
                        CoderOriginal[i, j] = fileBytes[HeaderSize + ImageSize * i + j];
                    }
                }
            }

            refreshHistogramButton_Click(sender, e);
        }

        private void encodeButton_Click(object sender, EventArgs e)
        {
            int k = (int)kNumericUpDown.Value;
            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    CoderPrediction[i, j] = (byte)PredictPixel(CoderDecoded, i, j);
                    CoderErrorPrediction[i, j] = CoderOriginal[i, j] - CoderPrediction[i, j];
                    CoderErrorPredictionQ[i, j] = (int)Math.Floor((CoderErrorPrediction[i, j] + k) / (2.0 * k + 1));
                    CoderErrorPredictionDQ[i, j] = CoderErrorPredictionQ[i, j] * (2 * k + 1);
                    CoderPrediction2[i, j] = (byte)PredictPixel(CoderDecoded, i, j);
                    CoderDecoded[i, j] = (CoderErrorPredictionDQ[i, j] + CoderPrediction2[i, j]).NormalizePixelValue();
                    CoderError[i, j] = CoderOriginal[i, j] - CoderDecoded[i, j];
                }
            }
        }

        private int PredictPixel(byte[,] matrix, int i, int j)
        {
            if ((i == 0 && j == 0) || Predictor == PredictorType.P128)
            {
                return 128;
            }

            if (i == 0 && j != 0) return matrix[i, j - 1];
            if (i != 0 && j == 0) return matrix[i - 1, j];
            switch (Predictor)
            {
                case PredictorType.A: return matrix[i, j - 1];
                case PredictorType.B: return matrix[i - 1, j];
                case PredictorType.C: return matrix[i - 1, j - 1];
                case PredictorType.AplusBminusC: return (matrix[i, j - 1] + matrix[i - 1, j] - matrix[i - 1, j - 1]).NormalizePixelValue();
                case PredictorType.AplusBminusCdiv: return (matrix[i, j - 1] + (matrix[i - 1, j] - matrix[i - 1, j - 1]) / 2).NormalizePixelValue();
                case PredictorType.BplusAminusCdiv: return (matrix[i - 1, j] + (matrix[i, j - 1] - matrix[i - 1, j - 1]) / 2).NormalizePixelValue();
                case PredictorType.AplusBdiv: return ((matrix[i, j - 1] + matrix[i - 1, j]) / 2).NormalizePixelValue();
                case PredictorType.JpegLS:
                    if (matrix[i - 1, j - 1] >= Math.Max(matrix[i, j - 1], matrix[i - 1, j]))
                    {
                        return Math.Min(matrix[i, j - 1], matrix[i - 1, j]);

                    }
                    else if (matrix[i - 1, j - 1] <= Math.Min(matrix[i, j - 1], matrix[i - 1, j]))
                    {
                        return Math.Max(matrix[i, j - 1], matrix[i - 1, j]);
                    }
                    else
                    {
                        return (matrix[i - 1, j] + matrix[i - 1, j] - matrix[i - 1, j - 1]).NormalizePixelValue();
                    }
                default: return 128;
            }
        }

        private void refreshErrorImageButton_Click(object sender, EventArgs e)
        {
            Bitmap errorImage = new Bitmap(ImageSize, ImageSize);
            double contrast = (double)contrastNumericUpDown.Value;
            double pixel;
            int[,] errorMatrixToUse;
            if (predictionErrorRadioButton.Checked)
            {
                errorMatrixToUse = CoderErrorPrediction;
            }
            else
            {
                errorMatrixToUse = CoderErrorPredictionQ;
            }

            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    pixel = errorMatrixToUse[i, j] * contrast + 128;
                    byte normalizedPixel = ((int)Math.Floor(pixel)).NormalizePixelValue();
                    errorImage.SetPixel(i, j, Color.FromArgb(normalizedPixel, normalizedPixel, normalizedPixel));
                }
            }
            errorPictureBox.Image = errorImage;
            errorImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
        }

        #region RadioButtons CheckedChange Events
        private void p128RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.P128;
        }

        private void pARadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.A;
        }

        private void pBRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.B;
        }

        private void pCRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.C;
        }

        private void pApBmCRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.AplusBminusC;
        }

        private void pApBmCd2RadioButton6_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.AplusBminusCdiv;
        }

        private void BpAmCd2RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.BplusAminusCdiv;
        }

        private void ApBd2RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.AplusBdiv;
        }

        private void jpeglsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Predictor = PredictorType.JpegLS;
        }

        private void histOriginalRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramImageMatrix = CoderOriginal;
            refreshHistogramButton_Click(sender, e);
        }

        private void histCoderPredRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramErrorMatrix = CoderErrorPrediction;
            refreshHistogramButton_Click(sender, e);
        }

        private void histCoderQPredRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramErrorMatrix = CoderErrorPredictionQ;
            refreshHistogramButton_Click(sender, e);
        }

        private void histCoderDecodedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramImageMatrix = CoderDecoded;
            refreshHistogramButton_Click(sender, e);
        }

        private void histDecoderPredRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramErrorMatrix = DecoderErrorPrediction;
            refreshHistogramButton_Click(sender, e);
        }

        private void histDecoderQPredRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramErrorMatrix = DecoderErrorPredictionQ;
            refreshHistogramButton_Click(sender, e);
        }

        private void histDecoderDecodedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            HistogramImageMatrix = DecoderDecoded;
            refreshHistogramButton_Click(sender, e);
        }

        #endregion

        private void refreshHistogramButton_Click(object sender, EventArgs e)
        {
            double scale = (double)histScaleNumericUpDown.Value;
            int[] counts = new int[HistogramSize];

            if (HistogramImageMatrix == null)
            {
                HistogramImageMatrix = CoderOriginal;
            }
            if (histOriginalRadioButton.Checked || histCoderDecodedRadioButton.Checked || histDecoderDecodedRadioButton.Checked)
            {
                for (int i = 0; i < ImageSize; i++)
                {
                    for (int j = 0; j < ImageSize; j++)
                    {
                        counts[HistogramSize / 2 + HistogramImageMatrix[i, j]]++;
                    }
                }
            }
            else
            {
                for (int i = 0; i < ImageSize; i++)
                {
                    for (int j = 0; j < ImageSize; j++)
                    {
                        counts[HistogramSize / 2 + HistogramErrorMatrix[i, j]]++;
                    }
                }
            }

            Graphics graphics = histogramPictureBox.CreateGraphics();
            graphics.Clear(Color.White);
            for (int i = 0; i < HistogramSize; i++)
            {
                graphics.DrawLine(new Pen(Color.Gray, 1), i, histogramPictureBox.Height - (int)(counts[i] * scale), i, histogramPictureBox.Height);
            }
            graphics.DrawLine(new Pen(Color.Red, 1), HistogramSize / 2, 0, HistogramSize / 2, histogramPictureBox.Height);
        }

        private void saveOriginalButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefile = new SaveFileDialog();
            savefile.Filter = "NL Pred|*.nlp";
            savefile.InitialDirectory = string.Format(@"{0}\Encoded", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));

            if (fixedRadioButton.Checked)
            {
                savefile.FileName = string.Format("EncodedImage.bmp.K{0}p{1}F.nlp", kNumericUpDown.Value.ToString(), ((int)Predictor).ToString());
                if (savefile.ShowDialog() == DialogResult.OK)
                {
                    BitWriter bitWriter = new BitWriter(savefile.FileName);
                    WriteHeader(bitWriter, SavingType.Fixed);

                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {
                            bitWriter.WriteNBits((uint)CoderErrorPredictionQ[i, j] + 255, SaveingPicturePixelSize);
                        }
                    }

                    bitWriter.Close();
                }
            }
            if (tableRadioButton.Checked)
            {
                savefile.FileName = string.Format("EncodedImage.bmp.K{0}p{1}T.nlp", kNumericUpDown.Value.ToString(), ((int)Predictor).ToString());
                if (savefile.ShowDialog() == DialogResult.OK)
                {
                    BitWriter bitWriter = new BitWriter(savefile.FileName);
                    WriteHeader(bitWriter, SavingType.Table);

                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {

                            if (CoderErrorPredictionQ[i, j] == 0)
                            {
                                bitWriter.WriteBit(0);
                            }
                            else
                            {
                                double line;
                                if (CoderErrorPredictionQ[i, j] < 0)
                                {
                                    line = Math.Floor(Math.Log(CoderErrorPredictionQ[i, j] * (-1), 2)) + 1;
                                }
                                else
                                {
                                    line = Math.Floor(Math.Log(CoderErrorPredictionQ[i, j], 2)) + 1;
                                }
                                double column;
                                if (CoderErrorPredictionQ[i, j] < 0)
                                {
                                    column = Math.Pow(2, line) - 1 + CoderErrorPredictionQ[i, j];
                                }
                                else
                                {
                                    column = CoderErrorPredictionQ[i, j];
                                }

                                for (int k = 0; k < line; k++)
                                {
                                    bitWriter.WriteBit(1);
                                }
                                bitWriter.WriteBit(0);
                                bitWriter.WriteNBits((uint)column, (int)line);
                            }
                        }
                    }
                    bitWriter.Close();
                }
            }
        }

        private void WriteHeader(BitWriter bitWriter, SavingType savingType)
        {
            for (int i = 0; i < HeaderSize; i++)
            {
                bitWriter.WriteNBits(HeaderBytes[i], BmpHeaderBitCount);
            }

            bitWriter.WriteNBits((uint)kNumericUpDown.Value, KHeaderBitCount);
            bitWriter.WriteNBits((uint)Predictor, PredictorHeaderBitCount);
            bitWriter.WriteNBits((uint)savingType, SavingTypeHeaderBitCount);
        }

        private void loadEncodedButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Choose Encoded Picture";
            dialog.Filter = "NL PRED files|*.nlp";
            dialog.InitialDirectory = string.Format(@"{0}\Encoded", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                OpenedNlpFileName = dialog.FileName;
                BitReader bitReader = new BitReader(OpenedNlpFileName);
                for (int i = 0; i < HeaderSize; i++)
                {
                    HeaderBytes[i] = (byte)bitReader.ReadNBits(8);
                }

                DecoderK = (int)bitReader.ReadNBits(KHeaderBitCount);
                Predictor = (PredictorType)(int)bitReader.ReadNBits(PredictorHeaderBitCount);
                SavingType savedFormat = (SavingType)(int)bitReader.ReadNBits(SavingTypeHeaderBitCount);

                if (savedFormat == SavingType.Fixed)
                {
                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {
                            DecoderErrorPredictionQ[i, j] = ((int)bitReader.ReadNBits(SaveingPicturePixelSize)) - 255;
                        }
                    }
                }
                else if (savedFormat == SavingType.Table)
                {
                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {
                            int ct = 1;
                            if (bitReader.ReadBit() == 0)
                            {
                                DecoderErrorPredictionQ[i, j] = 0;
                            }
                            else
                            {
                                while (bitReader.ReadBit() != 0)
                                {
                                    ct++;
                                }
                                int col = (int)bitReader.ReadNBits(ct);
                                double power = Math.Pow(2, ct - 1);
                                DecoderErrorPredictionQ[i, j] = col < power ? col - (int)(Math.Pow(2, ct) - 1) : col;
                            }

                        }
                    }
                }
                bitReader.Close();
            }
        }

        private void decodeButton_Click(object sender, EventArgs e)
        {
            Bitmap decodedImage = new Bitmap(ImageSize, ImageSize);
            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    DecoderErrorPredictionDQ[i, j] = DecoderErrorPredictionQ[i, j] * (2 * DecoderK + 1);
                    DecoderPrediction[i, j] = (byte)PredictPixel(DecoderDecoded, i, j);
                    DecoderDecoded[i, j] = (DecoderErrorPredictionDQ[i, j] + DecoderPrediction[i, j]).NormalizePixelValue();
                    DecoderErrorPrediction[i, j] = CoderOriginal[i, j] - DecoderDecoded[i, j];
                    decodedImage.SetPixel(i, j, Color.FromArgb(DecoderDecoded[i, j], DecoderDecoded[i, j], DecoderDecoded[i, j]));
                }
            }

            decodedPictureBox.Image = decodedImage;
            decodedImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
        }

        private void computeErrorButton_Click(object sender, EventArgs e)
        {
            double min, max;
            min = double.MaxValue;
            max = double.MinValue;

            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    if (DecoderErrorPrediction[i, j] < min) min = DecoderErrorPrediction[i, j];
                    if (DecoderErrorPrediction[i, j] > max) max = DecoderErrorPrediction[i, j];
                }
            }

            minErrorTextBox.Text = min.ToString();
            maxErrorTextBox.Text = max.ToString();
        }

        private void saveDecodedButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefile = new SaveFileDialog();
            savefile.Filter = "BMP images|*.bmp";
            savefile.InitialDirectory = string.Format(@"{0}\Encoded", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            savefile.FileName = string.Format("{0}.bmp", OpenedNlpFileName.Split('\\').Last());

            if (savefile.ShowDialog() == DialogResult.OK)
            {
                BitWriter bitWriter = new BitWriter(savefile.FileName);
                for (int i = 0; i < HeaderSize; i++)
                {
                    bitWriter.WriteNBits(HeaderBytes[i], 8);
                }

                for (int i = 0; i < ImageSize; i++)
                {
                    for (int j = 0; j < ImageSize; j++)
                    {
                        bitWriter.WriteNBits(DecoderDecoded[i, j], 8);
                    }
                }
                bitWriter.Close();
            }

        }

        private void scaleTrackBar_ValueChanged(object sender, EventArgs e)
        {
            histScaleNumericUpDown.Value = (decimal)((double)scaleTrackBar.Value / 100);
        }

        private void histScaleNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            refreshHistogramButton_Click(sender, e);
        }
    }
}
