﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NearLossless
{
    public static class Extensions
    {
        public static byte NormalizePixelValue(this int val)
        {
            if (val > 255) return 255;
            if (val < 0) return 0;
            return (byte)val;
        }
    }
}
