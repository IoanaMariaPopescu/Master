﻿using PredictiveCoder.Actions;
using PredictiveCoder.Controller;
using PredictiveCoder.Utils;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace PredictiveCoder
{
    public partial class PredictiveCoder : Form
    {
        private EncodingHolder encodingHolder; 

        public PredictiveCoder()
        {
            InitializeComponent();
        }

        private void PredictiveCoder_Load(object sender, EventArgs e)
        {
            originalImageLabel.Text = "";
            decodedImageLabel.Text = "";
            encodeButton.Enabled = false;
            saveOriginalButton.Enabled = false;
            EncoderUtils.Declaration(); 
        }
       

    private void loadOriginalButton_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "BMP | *.bmp";
            openFileDialog.Title = "Open BMP file";
            openFileDialog.InitialDirectory = @"D:\Master\An1\sem 2\Laboratoare\PredictiveCoder";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string inputFile = openFileDialog.FileName;
                EncoderUtils.inputFileName = inputFile;
                EncoderUtils.Initialize();
                Bitmap bitmap = new Bitmap(inputFile);
                if (bitmap.Width > originalImage.ClientSize.Width || bitmap.Height > originalImage.ClientSize.Height)
                {
                    originalImage.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    originalImage.SizeMode = PictureBoxSizeMode.CenterImage;
                }
                   
                originalImage.Image = bitmap;
                encodeButton.Enabled = true;
            }
        }

        private void encodeButton_Click(object sender, EventArgs e)
        {
            saveOriginalButton.Enabled = true;
            //EncoderUtils.outputFileName = EncoderUtils.inputFileName + ".p" + predictorsList.SelectedIndex.ToString() + "k" + kvalueUpDown.Value.ToString() + saveMethodListbox.SelectedItem.ToString().Substring(0, 1) +
            //               ".prd";
            encodingHolder = new EncodingHolder(originalImage, errorImage, predictorsList, saveMethodListbox, kvalueUpDown);
            EncoderAction encoderAction = new EncoderAction(encodingHolder);
            encoderAction.Encode();
            errorImage.Image = EncoderUtils.DrawImage(encodingHolder.ep);

            if (errorImage.Image.Width > errorImage.ClientSize.Width || errorImage.Image.Height > errorImage.ClientSize.Height)
            {
                errorImage.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else
            {
                errorImage.SizeMode = PictureBoxSizeMode.CenterImage;
            }

            int selectedIndex = histogramListBox.SelectedIndex;
            int[] frequencies;
            if (selectedIndex == 0)
                frequencies = GetFrequencies(encodingHolder.o);
            else
                if (selectedIndex == 1)
                frequencies = GetFrequencies(encodingHolder.ep);

            else
                if (selectedIndex == 2)
                frequencies = GetFrequencies(encodingHolder.epq);
            else
                frequencies = GetFrequencies(encodingHolder.epd);

            float scale = (float)histoScaleNumeric.Value;
            DrawHist(frequencies, scale);
        }

        public void DrawHist(int[] freq, float scale)
        {
            using (Graphics g = histogramPanel.CreateGraphics())
            {
                g.Clear(BackColor);

                for (int i = 0; i < freq.Length; i++)
                {
                    g.DrawLine(Pens.DarkRed, i, 255, i, 255 - freq[i] * scale);
                }
            }
        }

        public int[] GetFrequencies(int[,] matrix)
        {
            int[] freq = new int[511];
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < 256; j++)
                {
                    int indexValue = matrix[i, j] + 255;
                    freq[indexValue]++;
                }
            }

            return freq;
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            double scalingValue = (double)scaleNumeric.Value;
            int[,] scaledMatrix = new int[256, 256];

            if (predListbox.SelectedIndex == 0)
            {
                for (int i = 0; i < 256; i++)
                {
                    for (int j = 0; j < 256; j++)
                    {
                        scaledMatrix[i, j] = (int)((EncoderUtils.ErPredictionMatrix[i, j] * scalingValue + 128));
                    }
                }
                errorImage.Image = EncoderUtils.DrawImage(scaledMatrix);
            }
            else
                 if (predListbox.SelectedIndex == 1)
            {
                for (int i = 0; i < 256; i++)
                {
                    for (int j = 0; j < 256; j++)
                    {
                        scaledMatrix[i, j] = (int)((EncoderUtils.ErPredictionQMatrix[i, j] * scalingValue + 128));
                    }
                }
                errorImage.Image = EncoderUtils.DrawImage(scaledMatrix);
            }
        }

        private void saveOriginalButton_Click(object sender, EventArgs e)
        {
            //SaveErrorPqUsingFixed9Bits(saveMethodListbox.SelectedValue.ToString());
        }

        public void SaveErrorPqUsingFixed9Bits(string saveMode)
        {
            int sMode = 0; ;
            if (saveMode == "Fixed 9")
                sMode = 0;
            BitWriter.InitWriter(EncoderUtils.outputFileName);
            EncoderUtils.WriteBmpHeader();
            BitWriter.WriteNBits(Convert.ToUInt32(predictorsList.SelectedIndex), 4);
            BitWriter.WriteNBits(Convert.ToUInt32(KvalueLabel), 4);
            BitWriter.WriteNBits(Convert.ToUInt32(sMode), 2);
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < 256; j++)
                {
                    uint value = Convert.ToUInt32(encodingHolder.epq[i,j] + 255);
                    BitWriter.WriteNBits(value, 9);
                }
            }
        
            BitWriter.WriteNBits(0, 7);
            BitWriter.CloseWriter();
        }

    }
}
