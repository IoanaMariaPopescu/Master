﻿using PredictiveCoder.Controller;
using PredictiveCoder.Predictors;
using PredictiveCoder.SaveModes;

namespace PredictiveCoder.Actions
{
    public class EncoderAction
    {
        private EncodingHolder _encoder;

        public EncoderAction(EncodingHolder encoder)
        {
            this._encoder = encoder;
        }

        public void Encode()
        {
            _encoder.preEncoding();

            AbstractPredictor predictor = PredictorFactory.createPredictor(_encoder.predictorType);
            KQuantizer quantizer = new KQuantizer(_encoder.k);

            for (int i = 0; i < EncodingHolder.SIZE; ++i)
            {
                for (int j = 0; j < EncodingHolder.SIZE; ++j)
                {
                    _encoder.p[i,j] = predictor.Predict(_encoder.r, i, j);
                    _encoder.ep[i,j] = _encoder.o[i,j] - _encoder.p[i,j];
                    _encoder.epq[i,j] = quantizer.Quantize(_encoder.ep[i,j]);
                    _encoder.epd[i,j] = quantizer.Dequantize(_encoder.epq[i,j]);
                    _encoder.r[i,j] = _encoder.epd[i,j] + _encoder.p[i,j];
                }
            }
        }
    }
}
