﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.Predictors
{
    public class JpegLsPredictor : AbstractPredictor
    {
        protected override int Predict(int A, int B, int C)
        {
            if (C >= Math.Max(A, B))
            {
                return Math.Min(A, B);
            }
            else if (C <= Math.Min(A, B))
            {
                return Math.Max(A, B);
            }
            else
            {
                return A + B - C;
            }
        }
    }
}
