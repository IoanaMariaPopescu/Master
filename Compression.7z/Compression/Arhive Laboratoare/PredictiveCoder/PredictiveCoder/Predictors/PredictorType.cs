﻿namespace PredictiveCoder.Predictors
{
    public enum PredTypes
    {
        NONE,
        I28 = 0,
        A = 1,
        B = 2,
        C = 3,
        ApBmC = 4,
        ApBmCd2 = 5,
        BpAmCd2 = 6,
        ApBd2 = 7,
        JPEG_LS = 8
    };

    public class PredictorType
    {       
        private int index;

        PredictorType(int idx)
        {
            this.index = idx;
        }

        public int getIndex()
        {
            return index;
        }

        public static PredTypes getPredictorType(int index)
        {
            switch (index)
            {
                case 0:
                    return PredTypes.I28;
                case 1:
                    return PredTypes.A;
                case 2:
                    return PredTypes.B;
                case 3:
                    return PredTypes.C;
                case 4:
                    return PredTypes.ApBmC;
                case 5:
                    return PredTypes.ApBmCd2;
                case 6:
                    return PredTypes.BpAmCd2;
                case 7:
                    return PredTypes.ApBd2;
                case 8: return PredTypes.JPEG_LS;
                default:
                    return PredTypes.NONE;
            }
        }
    }

    
}
