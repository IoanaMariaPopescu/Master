﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.Predictors
{
    public class BpAmCd2Predictor : AbstractPredictor
    {
        protected override int Predict(int A, int B, int C)
        {
            return B + (A - C) / 2;
        }
    }
}
