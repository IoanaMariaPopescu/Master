﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.Predictors
{
    public class PredictorFactory
    {
        public static AbstractPredictor createPredictor(PredTypes predTypes)
        {
            switch (predTypes)
            {
                case PredTypes.I28:
                    return new I28Predictor();
                case PredTypes.A:
                    return new APredictor();
                case PredTypes.B:
                    return new BPredictor();
                case PredTypes.C:
                    return new CPredictor();
                case PredTypes.ApBmC:
                    return new ApBmCPredictor();
                case PredTypes.ApBmCd2:
                    return new ApBmCd2Predictor();
                case PredTypes.BpAmCd2:
                    return new BpAmCd2Predictor();
                case PredTypes.ApBd2:
                    return new ApBd2Predictor();
                case PredTypes.JPEG_LS:
                    return new JpegLsPredictor();
                default:
                    return null;
            }
        }
    }
}
