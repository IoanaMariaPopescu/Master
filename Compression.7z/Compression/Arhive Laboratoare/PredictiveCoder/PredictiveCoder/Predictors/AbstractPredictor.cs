﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.Predictors
{
    public abstract class AbstractPredictor
    {
        public int Predict(int[,] image, int row, int col)
        {
            if(row == 0 && col == 0)
            {
                return 128;
            }
            else if(row == 0) 
            {
                return image[row,col - 1];
            }
            else if(col == 0)
            {
                return image[row - 1,col];
            }
            else
            {
                return Predict(image[row,col - 1], image[row - 1,col], image[row - 1,col - 1]);
            }
        }

        protected abstract int Predict(int A, int B, int C);
    }
}
