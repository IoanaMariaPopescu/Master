﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.Utils
{
    public class EncoderUtils
    {
        public static int[,] OriginalMatrix;
        public static int[,] PredictionMatrix;
        public static int[,] ErPredictionMatrix;
        public static int[,] ErPredictionQMatrix;
        public static int[,] ErPredictionDqMatrix;
        public static int[,] PredictionToMatrix;
        public static int[,] Decoder;
        public static int[,] Error;

        public static string inputFileName;
        public static string outputFileName;
        public static byte[] bmpHeader;
        public static int maxError = -100000;
        public static int minError = 100000;

        public static void Declaration()
        {
            OriginalMatrix = new int[256, 256];
            PredictionMatrix = new int[256, 256];
            ErPredictionMatrix = new int[256, 256];
            ErPredictionQMatrix = new int[256, 256];
            ErPredictionDqMatrix = new int[256, 256];
            PredictionToMatrix = new int[256, 256];
            Decoder = new int[256, 256];
            Error = new int[256, 256];
            bmpHeader = new byte[1078];
        }

        public static void Initialize()
        {
            for (int i = 0; i < 256; i++)
                for (int j = 0; j < 256; j++)
                {
                    OriginalMatrix[i, j] = 0;
                    PredictionMatrix[i, j] = 0;
                    ErPredictionMatrix[i, j] = 0;
                    ErPredictionQMatrix[i, j] = 0;
                    ErPredictionDqMatrix[i, j] = 0;
                    PredictionToMatrix[i, j] = 0;
                    Decoder[i, j] = 0;
                    Error[i, j] = 0;
                }
        }

        public static void ReadBmpHeader()
        {
            for (int i = 0; i < 1078; i++)
                bmpHeader[i] = (byte)BitReader.ReadNBit(8);
        }

        public static void WriteBmpHeader()
        {
            foreach (byte b in bmpHeader)
                BitWriter.WriteNBits(b, 8);
        }

        public static Bitmap DrawImage(int[,] matrix)
        {
            Bitmap bitmap = new Bitmap(256, 256);
            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j < 256; j++)
                {
                    int value = matrix[i, j];

                    if (value < 0)
                        value = 0;
                    if (value > 255)
                        value = 255;
                    Color color = Color.FromArgb(255, value, value, value);
                    bitmap.SetPixel(j, i, color);
                }
            }

            return bitmap;
        }

        public static int GetA(int x, int y)
        {
            if (x == 0)
                return 128;
            else
                return Decoder[x - 1, y];
        }

        public static int GetB(int x, int y)
        {
            if (y == 0)
                return 128;
            else
                return Decoder[x, y - 1];
        }

        public static int GetC(int x, int y)
        {
            if (x == 0)
                return GetA(x, y);
            else if (y == 0)
                return GetB(x, y);
            else
                return Decoder[x - 1, y - 1];

        }
    }
}
