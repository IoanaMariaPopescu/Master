﻿using System.IO;

namespace PredictiveCoder.Utils
{
    public static class BitWriter
    {
        static FileStream writer;
        public static int writeCounter = 0;
        public static byte buffer;

        public static void InitWriter(string fileName)
        {
            writeCounter = 0;
            writer = new FileStream(fileName, FileMode.Create, FileAccess.Write);
        }
        
        public static void CloseWriter()
        {
            writer.Close();
        }

        public static void WriteBit(int bit)
        {
            buffer = (byte)(buffer | (bit << (7 - writeCounter % 8)));
            writeCounter++;

            if(writeCounter % 8 == 0)
            {
                writer.WriteByte(buffer);
                buffer = 0;
            }
        }

        public static void WriteNBits(uint bits, int numberOfBits)
        {
            for (int i = 0; i < numberOfBits; i++)
                WriteBit((int)(bits >> numberOfBits - i - 1));
        }
    }
}
