﻿using System;
using System.Drawing;

namespace PredictiveCoder.Utils
{
    public class ImageUtils
    {
        public static int[,] adaptImageToMatrix(Bitmap sourceImage)
        {
            int rows = sourceImage.Height;
            int cols = sourceImage.Width;
            int[,] matrix = new int[rows,cols];
            for (int x = 0; x < rows; ++x)
            {
                for (int y = 0; y < cols; ++y)
                {
                    Color color = sourceImage.GetPixel(x, y);
                    matrix[y,x] = color.B;
                }
            }
            return matrix;
        }

        public static Bitmap adaptMatrixToImage(int[,] matrix)
        {
            int height = matrix.GetLength(0);
            int width = matrix.GetLength(1);
            Bitmap image = new Bitmap(width, height);
            for (int x = 0; x < height; ++x)
            {
                for (int y = 0; y < width; ++y)
                {
                    int val = matrix[x,y];
                    val = Math.Max(Math.Min(val, 255), 0);
                    Color color = Color.FromArgb(val, val, val);
                    image.SetPixel(y, x, color);
                }
            }
            return image;
        }

        public static int[,] adaptIconToMatrix(Bitmap bitmap)
        {
            int[,] matrix = ImageUtils.adaptImageToMatrix(bitmap);
            return matrix;
        }

        public static Bitmap adaptMatrixToIcon(int[,] matrix)
        {
            return adaptMatrixToImage(matrix);
        }
    }
}
