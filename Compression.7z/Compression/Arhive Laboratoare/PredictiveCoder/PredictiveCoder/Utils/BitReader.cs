﻿using System.IO;
using System.Linq;

namespace PredictiveCoder.Utils
{
    public static class BitReader
    {
        public static int readCounter = 0;
        public static byte buffer;
        static FileStream fileReader;

        public static void InitReader(string fileName)
        {
            readCounter = 0;
            fileReader = new FileStream(fileName, FileMode.Open, FileAccess.Read);
        }

        public static byte ReadBit()
        {
            if(readCounter % 8 == 0)
            {
                buffer = (byte)fileReader.ReadByte();
            }
            byte value = (byte)((buffer >> (7 - (readCounter % 8))) & 0x01);
            readCounter++;
            return value;
        }

        public static uint ReadNBit(int numberOfBits)
        {
            uint value = 0;
            for(int i = 0; i < numberOfBits; i++)
            {
                byte bit = ReadBit();
                value = (uint)(value | (uint)(bit << (numberOfBits - i - 1)));
            }
            return value;
        }

    }
}
