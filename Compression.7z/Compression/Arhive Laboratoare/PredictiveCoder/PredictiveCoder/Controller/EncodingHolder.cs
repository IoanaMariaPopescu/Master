﻿using PredictiveCoder.Predictors;
using PredictiveCoder.SaveModes;
using PredictiveCoder.Utils;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PredictiveCoder.Controller
{
    public class EncodingHolder
    {
        public static int SIZE = 256;

        private PictureBox _originalImage;
        private PictureBox _destinationImage;
        private ListBox _predictorsListBox;
        private ListBox _saveModeListBox;
        private NumericUpDown _kValue;

        public PredTypes predictorType = PredTypes.I28;
        public Mode saveMode = Mode.FIXED_32;
        public int k = 0;

        public int[,] epq;
        public int[,] ep;
        public int[,] o;
        public int[,] p;
        public int[,] epd;
        public int[,] r;

        public EncodingHolder(PictureBox originalImage, PictureBox destinationImage, ListBox predictorsListBox, ListBox saveModeListBox, NumericUpDown kValue)
        {
            this._originalImage = originalImage;
            this._destinationImage = destinationImage;
            this._predictorsListBox = predictorsListBox;
            this._saveModeListBox = saveModeListBox;
            this._kValue = kValue;
        }

        public void preEncoding()
        {
            o = new int[SIZE,SIZE];
            ep = new int[SIZE, SIZE];
            epq = new int[SIZE, SIZE];
            p = new int[SIZE, SIZE];
            epd = new int[SIZE, SIZE];
            r = new int[SIZE, SIZE];

            Bitmap bitmap = (Bitmap)_originalImage.Image;
            o = ImageUtils.adaptIconToMatrix(bitmap);
            predictorType = PredictorType.getPredictorType(_predictorsListBox.SelectedIndex);
            getSaveMode();
            k = (int)_kValue.Value;
        }

        public void getSaveMode()
        {
            saveMode = SaveMode.getSaveMode(_saveModeListBox.SelectedIndex);
        }

        public void preDecoding()
        {
            epd = new int[SIZE, SIZE];
            r = new int[SIZE, SIZE];
            p = new int[SIZE, SIZE];
        }

        public void postDecoding()
        {
            Bitmap icon = ImageUtils.adaptMatrixToIcon(r);
            _destinationImage.Image = icon;
        }
    }
}
