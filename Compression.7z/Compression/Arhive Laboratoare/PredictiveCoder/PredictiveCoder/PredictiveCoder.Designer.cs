﻿namespace PredictiveCoder
{
    partial class PredictiveCoder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalImage = new System.Windows.Forms.PictureBox();
            this.errorImage = new System.Windows.Forms.PictureBox();
            this.decodedImage = new System.Windows.Forms.PictureBox();
            this.delimiter = new System.Windows.Forms.Panel();
            this.loadDecodedButton = new System.Windows.Forms.Button();
            this.decodeButton = new System.Windows.Forms.Button();
            this.saveDecodedButton = new System.Windows.Forms.Button();
            this.refreshButton = new System.Windows.Forms.Button();
            this.originalImageLabel = new System.Windows.Forms.Label();
            this.decodedImageLabel = new System.Windows.Forms.Label();
            this.loadOriginalButton = new System.Windows.Forms.Button();
            this.encodeButton = new System.Windows.Forms.Button();
            this.saveOriginalButton = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.predictorsList = new System.Windows.Forms.ListBox();
            this.predictorsLabel = new System.Windows.Forms.Label();
            this.saveMethodLabel = new System.Windows.Forms.Label();
            this.saveMethodListbox = new System.Windows.Forms.ListBox();
            this.kvalueUpDown = new System.Windows.Forms.NumericUpDown();
            this.KvalueLabel = new System.Windows.Forms.Label();
            this.predListbox = new System.Windows.Forms.ListBox();
            this.scaleNumeric = new System.Windows.Forms.NumericUpDown();
            this.scaleLabel = new System.Windows.Forms.Label();
            this.histogramPanel = new System.Windows.Forms.Panel();
            this.histogramListBox = new System.Windows.Forms.ListBox();
            this.histogramLabel = new System.Windows.Forms.Label();
            this.computeButton = new System.Windows.Forms.Button();
            this.minLabel = new System.Windows.Forms.Label();
            this.maxLabel = new System.Windows.Forms.Label();
            this.histoScaleNumeric = new System.Windows.Forms.NumericUpDown();
            this.histoScaleLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.decodedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kvalueUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.histoScaleNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // originalImage
            // 
            this.originalImage.BackColor = System.Drawing.SystemColors.ControlDark;
            this.originalImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.originalImage.Location = new System.Drawing.Point(16, 37);
            this.originalImage.Margin = new System.Windows.Forms.Padding(1);
            this.originalImage.Name = "originalImage";
            this.originalImage.Size = new System.Drawing.Size(359, 305);
            this.originalImage.TabIndex = 0;
            this.originalImage.TabStop = false;
            // 
            // errorImage
            // 
            this.errorImage.BackColor = System.Drawing.SystemColors.ControlDark;
            this.errorImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorImage.Location = new System.Drawing.Point(397, 34);
            this.errorImage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.errorImage.Name = "errorImage";
            this.errorImage.Size = new System.Drawing.Size(359, 308);
            this.errorImage.TabIndex = 1;
            this.errorImage.TabStop = false;
            // 
            // decodedImage
            // 
            this.decodedImage.BackColor = System.Drawing.SystemColors.ControlDark;
            this.decodedImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.decodedImage.Location = new System.Drawing.Point(791, 34);
            this.decodedImage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.decodedImage.Name = "decodedImage";
            this.decodedImage.Size = new System.Drawing.Size(359, 308);
            this.decodedImage.TabIndex = 2;
            this.decodedImage.TabStop = false;
            // 
            // delimiter
            // 
            this.delimiter.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.delimiter.Location = new System.Drawing.Point(765, 2);
            this.delimiter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.delimiter.Name = "delimiter";
            this.delimiter.Size = new System.Drawing.Size(17, 340);
            this.delimiter.TabIndex = 3;
            // 
            // loadDecodedButton
            // 
            this.loadDecodedButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadDecodedButton.Location = new System.Drawing.Point(1192, 48);
            this.loadDecodedButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loadDecodedButton.Name = "loadDecodedButton";
            this.loadDecodedButton.Size = new System.Drawing.Size(68, 39);
            this.loadDecodedButton.TabIndex = 4;
            this.loadDecodedButton.Text = "Load";
            this.loadDecodedButton.UseVisualStyleBackColor = true;
            // 
            // decodeButton
            // 
            this.decodeButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.decodeButton.Location = new System.Drawing.Point(1171, 119);
            this.decodeButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.decodeButton.Name = "decodeButton";
            this.decodeButton.Size = new System.Drawing.Size(89, 39);
            this.decodeButton.TabIndex = 5;
            this.decodeButton.Text = "Decode";
            this.decodeButton.UseVisualStyleBackColor = true;
            // 
            // saveDecodedButton
            // 
            this.saveDecodedButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveDecodedButton.Location = new System.Drawing.Point(1192, 186);
            this.saveDecodedButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.saveDecodedButton.Name = "saveDecodedButton";
            this.saveDecodedButton.Size = new System.Drawing.Size(68, 39);
            this.saveDecodedButton.TabIndex = 6;
            this.saveDecodedButton.Text = "Save";
            this.saveDecodedButton.UseVisualStyleBackColor = true;
            // 
            // refreshButton
            // 
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refreshButton.Location = new System.Drawing.Point(715, 359);
            this.refreshButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(87, 37);
            this.refreshButton.TabIndex = 7;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // originalImageLabel
            // 
            this.originalImageLabel.AutoSize = true;
            this.originalImageLabel.Location = new System.Drawing.Point(16, 16);
            this.originalImageLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.originalImageLabel.Name = "originalImageLabel";
            this.originalImageLabel.Size = new System.Drawing.Size(0, 17);
            this.originalImageLabel.TabIndex = 10;
            // 
            // decodedImageLabel
            // 
            this.decodedImageLabel.AutoSize = true;
            this.decodedImageLabel.Location = new System.Drawing.Point(829, 17);
            this.decodedImageLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.decodedImageLabel.Name = "decodedImageLabel";
            this.decodedImageLabel.Size = new System.Drawing.Size(0, 17);
            this.decodedImageLabel.TabIndex = 11;
            // 
            // loadOriginalButton
            // 
            this.loadOriginalButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadOriginalButton.Location = new System.Drawing.Point(20, 361);
            this.loadOriginalButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loadOriginalButton.Name = "loadOriginalButton";
            this.loadOriginalButton.Size = new System.Drawing.Size(75, 37);
            this.loadOriginalButton.TabIndex = 12;
            this.loadOriginalButton.Text = "Load";
            this.loadOriginalButton.UseVisualStyleBackColor = true;
            this.loadOriginalButton.Click += new System.EventHandler(this.loadOriginalButton_Click);
            // 
            // encodeButton
            // 
            this.encodeButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.encodeButton.Location = new System.Drawing.Point(169, 361);
            this.encodeButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.encodeButton.Name = "encodeButton";
            this.encodeButton.Size = new System.Drawing.Size(75, 37);
            this.encodeButton.TabIndex = 13;
            this.encodeButton.Text = "Encode";
            this.encodeButton.UseVisualStyleBackColor = true;
            this.encodeButton.Click += new System.EventHandler(this.encodeButton_Click);
            // 
            // saveOriginalButton
            // 
            this.saveOriginalButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveOriginalButton.Location = new System.Drawing.Point(301, 361);
            this.saveOriginalButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.saveOriginalButton.Name = "saveOriginalButton";
            this.saveOriginalButton.Size = new System.Drawing.Size(75, 37);
            this.saveOriginalButton.TabIndex = 14;
            this.saveOriginalButton.Text = "Save";
            this.saveOriginalButton.UseVisualStyleBackColor = true;
            this.saveOriginalButton.Click += new System.EventHandler(this.saveOriginalButton_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // predictorsList
            // 
            this.predictorsList.FormattingEnabled = true;
            this.predictorsList.ItemHeight = 16;
            this.predictorsList.Items.AddRange(new object[] {
            "128",
            "A",
            "B",
            "C",
            "A+B-C",
            "A+(B-C)/2",
            "B+(A-C)/2",
            "(A+B)/2",
            "JPEG-LS"});
            this.predictorsList.Location = new System.Drawing.Point(20, 482);
            this.predictorsList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.predictorsList.Name = "predictorsList";
            this.predictorsList.Size = new System.Drawing.Size(120, 148);
            this.predictorsList.TabIndex = 15;
            // 
            // predictorsLabel
            // 
            this.predictorsLabel.AutoSize = true;
            this.predictorsLabel.Location = new System.Drawing.Point(17, 450);
            this.predictorsLabel.Name = "predictorsLabel";
            this.predictorsLabel.Size = new System.Drawing.Size(76, 17);
            this.predictorsLabel.TabIndex = 17;
            this.predictorsLabel.Text = "Predictors:";
            // 
            // saveMethodLabel
            // 
            this.saveMethodLabel.AutoSize = true;
            this.saveMethodLabel.Location = new System.Drawing.Point(165, 450);
            this.saveMethodLabel.Name = "saveMethodLabel";
            this.saveMethodLabel.Size = new System.Drawing.Size(95, 17);
            this.saveMethodLabel.TabIndex = 18;
            this.saveMethodLabel.Text = "Save Method:";
            // 
            // saveMethodListbox
            // 
            this.saveMethodListbox.FormattingEnabled = true;
            this.saveMethodListbox.ItemHeight = 16;
            this.saveMethodListbox.Items.AddRange(new object[] {
            "Fixed 9",
            "Fixed 16",
            "Fixed 32",
            "Table",
            "Arithmetic"});
            this.saveMethodListbox.Location = new System.Drawing.Point(169, 482);
            this.saveMethodListbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveMethodListbox.Name = "saveMethodListbox";
            this.saveMethodListbox.Size = new System.Drawing.Size(108, 84);
            this.saveMethodListbox.TabIndex = 19;
            // 
            // kvalueUpDown
            // 
            this.kvalueUpDown.Location = new System.Drawing.Point(301, 482);
            this.kvalueUpDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kvalueUpDown.Name = "kvalueUpDown";
            this.kvalueUpDown.Size = new System.Drawing.Size(75, 22);
            this.kvalueUpDown.TabIndex = 20;
            this.kvalueUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // KvalueLabel
            // 
            this.KvalueLabel.AutoSize = true;
            this.KvalueLabel.Location = new System.Drawing.Point(299, 450);
            this.KvalueLabel.Name = "KvalueLabel";
            this.KvalueLabel.Size = new System.Drawing.Size(60, 17);
            this.KvalueLabel.TabIndex = 21;
            this.KvalueLabel.Text = "K-value:";
            // 
            // predListbox
            // 
            this.predListbox.FormattingEnabled = true;
            this.predListbox.ItemHeight = 16;
            this.predListbox.Items.AddRange(new object[] {
            "Prediction Error",
            "Q Prediction Error"});
            this.predListbox.Location = new System.Drawing.Point(397, 359);
            this.predListbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.predListbox.Name = "predListbox";
            this.predListbox.Size = new System.Drawing.Size(172, 36);
            this.predListbox.TabIndex = 22;
            // 
            // scaleNumeric
            // 
            this.scaleNumeric.DecimalPlaces = 2;
            this.scaleNumeric.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.scaleNumeric.Location = new System.Drawing.Point(604, 374);
            this.scaleNumeric.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.scaleNumeric.Name = "scaleNumeric";
            this.scaleNumeric.Size = new System.Drawing.Size(77, 22);
            this.scaleNumeric.TabIndex = 23;
            this.scaleNumeric.Value = new decimal(new int[] {
            17,
            0,
            0,
            65536});
            // 
            // scaleLabel
            // 
            this.scaleLabel.AutoSize = true;
            this.scaleLabel.Location = new System.Drawing.Point(601, 354);
            this.scaleLabel.Name = "scaleLabel";
            this.scaleLabel.Size = new System.Drawing.Size(47, 17);
            this.scaleLabel.TabIndex = 24;
            this.scaleLabel.Text = "Scale:";
            // 
            // histogramPanel
            // 
            this.histogramPanel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.histogramPanel.Location = new System.Drawing.Point(791, 450);
            this.histogramPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.histogramPanel.Name = "histogramPanel";
            this.histogramPanel.Size = new System.Drawing.Size(360, 206);
            this.histogramPanel.TabIndex = 25;
            // 
            // histogramListBox
            // 
            this.histogramListBox.FormattingEnabled = true;
            this.histogramListBox.ItemHeight = 16;
            this.histogramListBox.Items.AddRange(new object[] {
            "Original Image",
            "Prediction Error",
            "Q prediction Error",
            "Decoded Image"});
            this.histogramListBox.Location = new System.Drawing.Point(604, 507);
            this.histogramListBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.histogramListBox.Name = "histogramListBox";
            this.histogramListBox.Size = new System.Drawing.Size(136, 84);
            this.histogramListBox.TabIndex = 26;
            // 
            // histogramLabel
            // 
            this.histogramLabel.AutoSize = true;
            this.histogramLabel.Location = new System.Drawing.Point(604, 473);
            this.histogramLabel.Name = "histogramLabel";
            this.histogramLabel.Size = new System.Drawing.Size(76, 17);
            this.histogramLabel.TabIndex = 27;
            this.histogramLabel.Text = "Histogram:";
            // 
            // computeButton
            // 
            this.computeButton.Location = new System.Drawing.Point(397, 478);
            this.computeButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.computeButton.Name = "computeButton";
            this.computeButton.Size = new System.Drawing.Size(156, 28);
            this.computeButton.TabIndex = 28;
            this.computeButton.Text = "Compute error";
            this.computeButton.UseVisualStyleBackColor = true;
            // 
            // minLabel
            // 
            this.minLabel.AutoSize = true;
            this.minLabel.Location = new System.Drawing.Point(395, 549);
            this.minLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.minLabel.Name = "minLabel";
            this.minLabel.Size = new System.Drawing.Size(30, 17);
            this.minLabel.TabIndex = 29;
            this.minLabel.Text = "Min";
            // 
            // maxLabel
            // 
            this.maxLabel.AutoSize = true;
            this.maxLabel.Location = new System.Drawing.Point(395, 586);
            this.maxLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.maxLabel.Name = "maxLabel";
            this.maxLabel.Size = new System.Drawing.Size(33, 17);
            this.maxLabel.TabIndex = 30;
            this.maxLabel.Text = "Max";
            // 
            // histoScaleNumeric
            // 
            this.histoScaleNumeric.DecimalPlaces = 2;
            this.histoScaleNumeric.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.histoScaleNumeric.Location = new System.Drawing.Point(607, 635);
            this.histoScaleNumeric.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.histoScaleNumeric.Name = "histoScaleNumeric";
            this.histoScaleNumeric.Size = new System.Drawing.Size(55, 22);
            this.histoScaleNumeric.TabIndex = 31;
            this.histoScaleNumeric.Value = new decimal(new int[] {
            7,
            0,
            0,
            65536});
            // 
            // histoScaleLabel
            // 
            this.histoScaleLabel.AutoSize = true;
            this.histoScaleLabel.Location = new System.Drawing.Point(604, 613);
            this.histoScaleLabel.Name = "histoScaleLabel";
            this.histoScaleLabel.Size = new System.Drawing.Size(47, 17);
            this.histoScaleLabel.TabIndex = 32;
            this.histoScaleLabel.Text = "Scale:";
            // 
            // PredictiveCoder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1279, 676);
            this.Controls.Add(this.histoScaleLabel);
            this.Controls.Add(this.histoScaleNumeric);
            this.Controls.Add(this.maxLabel);
            this.Controls.Add(this.minLabel);
            this.Controls.Add(this.computeButton);
            this.Controls.Add(this.histogramLabel);
            this.Controls.Add(this.histogramListBox);
            this.Controls.Add(this.histogramPanel);
            this.Controls.Add(this.scaleLabel);
            this.Controls.Add(this.scaleNumeric);
            this.Controls.Add(this.predListbox);
            this.Controls.Add(this.KvalueLabel);
            this.Controls.Add(this.kvalueUpDown);
            this.Controls.Add(this.saveMethodListbox);
            this.Controls.Add(this.saveMethodLabel);
            this.Controls.Add(this.predictorsLabel);
            this.Controls.Add(this.predictorsList);
            this.Controls.Add(this.saveOriginalButton);
            this.Controls.Add(this.encodeButton);
            this.Controls.Add(this.loadOriginalButton);
            this.Controls.Add(this.decodedImageLabel);
            this.Controls.Add(this.originalImageLabel);
            this.Controls.Add(this.refreshButton);
            this.Controls.Add(this.saveDecodedButton);
            this.Controls.Add(this.decodeButton);
            this.Controls.Add(this.loadDecodedButton);
            this.Controls.Add(this.delimiter);
            this.Controls.Add(this.decodedImage);
            this.Controls.Add(this.errorImage);
            this.Controls.Add(this.originalImage);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "PredictiveCoder";
            this.Text = "PredictiveCoder";
            this.Load += new System.EventHandler(this.PredictiveCoder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.decodedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kvalueUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.histoScaleNumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox originalImage;
        private System.Windows.Forms.PictureBox errorImage;
        private System.Windows.Forms.PictureBox decodedImage;
        private System.Windows.Forms.Panel delimiter;
        private System.Windows.Forms.Button loadDecodedButton;
        private System.Windows.Forms.Button decodeButton;
        private System.Windows.Forms.Button saveDecodedButton;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Label originalImageLabel;
        private System.Windows.Forms.Label decodedImageLabel;
        private System.Windows.Forms.Button loadOriginalButton;
        private System.Windows.Forms.Button encodeButton;
        private System.Windows.Forms.Button saveOriginalButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ListBox predictorsList;
        private System.Windows.Forms.Label predictorsLabel;
        private System.Windows.Forms.Label saveMethodLabel;
        private System.Windows.Forms.ListBox saveMethodListbox;
        private System.Windows.Forms.NumericUpDown kvalueUpDown;
        private System.Windows.Forms.Label KvalueLabel;
        private System.Windows.Forms.ListBox predListbox;
        private System.Windows.Forms.NumericUpDown scaleNumeric;
        private System.Windows.Forms.Label scaleLabel;
        private System.Windows.Forms.Panel histogramPanel;
        private System.Windows.Forms.ListBox histogramListBox;
        private System.Windows.Forms.Label histogramLabel;
        private System.Windows.Forms.Button computeButton;
        private System.Windows.Forms.Label minLabel;
        private System.Windows.Forms.Label maxLabel;
        private System.Windows.Forms.NumericUpDown histoScaleNumeric;
        private System.Windows.Forms.Label histoScaleLabel;
    }
}

