﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.SaveModes
{
    public class KQuantizer
    {
        private int k;

        public KQuantizer(int k)
        {
            this.k = k;
        }

        public int Quantize(int val)
        {
            return (val + k) / (2 * k + 1);
        }

        public int Dequantize(int val)
        {
            return val * (2 * k + 1);
        }
    }
}
