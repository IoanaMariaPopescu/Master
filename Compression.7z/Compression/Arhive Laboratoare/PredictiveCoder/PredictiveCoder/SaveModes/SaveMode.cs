﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PredictiveCoder.SaveModes
{
    public enum Mode
    {
        NONE,
        FIXED_9 = 0,
        FIXED_16 = 1,
        FIXED_32 = 2,
        TABLE = 3,
        ARITHMETIC = 4
    };

    public class SaveMode
    {
        private int index;

        SaveMode(int idx)
        {
            this.index = idx;
        }

        public int getIndex()
        {
            return index;
        }

        public static Mode getSaveMode(int index)
        {
            switch (index)
            {
                case 0:
                    return Mode.FIXED_9;
                case 1:
                    return Mode.FIXED_16;
                case 2:
                    return Mode.FIXED_32;
                case 3:
                    return Mode.TABLE;
                case 4:
                    return Mode.ARITHMETIC;
                default:
                    return Mode.NONE;
            }
        }
    }
}
