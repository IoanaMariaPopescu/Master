﻿namespace ArithmeticCoder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.loadFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCompressedFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbOriginalFile = new System.Windows.Forms.RichTextBox();
            this.rtbCompressedFile = new System.Windows.Forms.RichTextBox();
            this.btnEncode = new System.Windows.Forms.Button();
            this.btnDecode = new System.Windows.Forms.Button();
            this.lblOriginalFileName = new System.Windows.Forms.Label();
            this.lblDecompressedFileName = new System.Windows.Forms.Label();
            this.ofdOriginalFile = new System.Windows.Forms.OpenFileDialog();
            this.ofdCompressedFile = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadFileToolStripMenuItem,
            this.loadCompressedFileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(873, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // loadFileToolStripMenuItem
            // 
            this.loadFileToolStripMenuItem.Name = "loadFileToolStripMenuItem";
            this.loadFileToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.loadFileToolStripMenuItem.Text = "Load File";
            this.loadFileToolStripMenuItem.Click += new System.EventHandler(this.loadFileToolStripMenuItem_Click);
            // 
            // loadCompressedFileToolStripMenuItem
            // 
            this.loadCompressedFileToolStripMenuItem.Name = "loadCompressedFileToolStripMenuItem";
            this.loadCompressedFileToolStripMenuItem.Size = new System.Drawing.Size(167, 24);
            this.loadCompressedFileToolStripMenuItem.Text = "Load Compressed File";
            this.loadCompressedFileToolStripMenuItem.Click += new System.EventHandler(this.loadCompressedFileToolStripMenuItem_Click);
            // 
            // rtbOriginalFile
            // 
            this.rtbOriginalFile.Location = new System.Drawing.Point(28, 113);
            this.rtbOriginalFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rtbOriginalFile.Name = "rtbOriginalFile";
            this.rtbOriginalFile.Size = new System.Drawing.Size(319, 191);
            this.rtbOriginalFile.TabIndex = 1;
            this.rtbOriginalFile.Text = "";
            // 
            // rtbCompressedFile
            // 
            this.rtbCompressedFile.Location = new System.Drawing.Point(515, 113);
            this.rtbCompressedFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rtbCompressedFile.Name = "rtbCompressedFile";
            this.rtbCompressedFile.Size = new System.Drawing.Size(319, 191);
            this.rtbCompressedFile.TabIndex = 2;
            this.rtbCompressedFile.Text = "";
            // 
            // btnEncode
            // 
            this.btnEncode.Location = new System.Drawing.Point(380, 146);
            this.btnEncode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEncode.Name = "btnEncode";
            this.btnEncode.Size = new System.Drawing.Size(109, 33);
            this.btnEncode.TabIndex = 3;
            this.btnEncode.Text = "Encode";
            this.btnEncode.UseVisualStyleBackColor = true;
            this.btnEncode.Click += new System.EventHandler(this.btnEncode_Click);
            // 
            // btnDecode
            // 
            this.btnDecode.Location = new System.Drawing.Point(380, 226);
            this.btnDecode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDecode.Name = "btnDecode";
            this.btnDecode.Size = new System.Drawing.Size(109, 33);
            this.btnDecode.TabIndex = 4;
            this.btnDecode.Text = "Decode";
            this.btnDecode.UseVisualStyleBackColor = true;
            this.btnDecode.Click += new System.EventHandler(this.btnDecode_Click);
            // 
            // lblOriginalFileName
            // 
            this.lblOriginalFileName.AutoSize = true;
            this.lblOriginalFileName.Location = new System.Drawing.Point(28, 90);
            this.lblOriginalFileName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOriginalFileName.Name = "lblOriginalFileName";
            this.lblOriginalFileName.Size = new System.Drawing.Size(46, 17);
            this.lblOriginalFileName.TabIndex = 5;
            this.lblOriginalFileName.Text = "label1";
            // 
            // lblDecompressedFileName
            // 
            this.lblDecompressedFileName.AutoSize = true;
            this.lblDecompressedFileName.Location = new System.Drawing.Point(511, 90);
            this.lblDecompressedFileName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDecompressedFileName.Name = "lblDecompressedFileName";
            this.lblDecompressedFileName.Size = new System.Drawing.Size(46, 17);
            this.lblDecompressedFileName.TabIndex = 6;
            this.lblDecompressedFileName.Text = "label1";
            // 
            // ofdOriginalFile
            // 
            this.ofdOriginalFile.FileName = "openFileDialog1";
            // 
            // ofdCompressedFile
            // 
            this.ofdCompressedFile.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 367);
            this.Controls.Add(this.lblDecompressedFileName);
            this.Controls.Add(this.lblOriginalFileName);
            this.Controls.Add(this.btnDecode);
            this.Controls.Add(this.btnEncode);
            this.Controls.Add(this.rtbCompressedFile);
            this.Controls.Add(this.rtbOriginalFile);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Arithmetic Coder";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem loadFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCompressedFileToolStripMenuItem;
        private System.Windows.Forms.RichTextBox rtbOriginalFile;
        private System.Windows.Forms.RichTextBox rtbCompressedFile;
        private System.Windows.Forms.Button btnEncode;
        private System.Windows.Forms.Button btnDecode;
        private System.Windows.Forms.Label lblOriginalFileName;
        private System.Windows.Forms.Label lblDecompressedFileName;
        private System.Windows.Forms.OpenFileDialog ofdOriginalFile;
        private System.Windows.Forms.OpenFileDialog ofdCompressedFile;
    }
}

