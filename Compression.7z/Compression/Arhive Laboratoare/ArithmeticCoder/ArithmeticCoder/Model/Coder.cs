﻿using ArithmeticCoder.IOController;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticCoder.Model
{
    public class Coder
    {
        #region Properties
        private int[] _counts;
        private int[] _lowValues;
        private int _symbolsCount;
        private int _eof;
        private uint _low;
        private uint _high;
        private int _underflowBits;
        private int _fileSize;
        private uint _decode;
        #endregion

        public Coder(int nr)
        {
            _eof = nr;
            _symbolsCount = ++nr;
            _counts = new int[nr + 1];
            _lowValues = new int[nr + 1];
            _low = 0;
            _high = Int32.MaxValue;
            _underflowBits = 0;

            //initialize arrays
            for (int i = 0; i < nr; i++)
            {
                _counts[i] = 1;
                _lowValues[i + 1] = _lowValues[i] + _counts[i];
            }
        }

        public void Update(int symbol)
        {
            _counts[symbol]++;

            for (int i = symbol + 1; i < _lowValues.Length; i++)
            {
                _lowValues[i]++;
            }
        }

        #region Encode
        public void Encode(String inputFile, String outputFile)
        {
            using (BitReader br = new BitReader(inputFile))
            {
                using (BitWriter bw = new BitWriter(outputFile))
                {
                    long size = br.GetFileSize(inputFile);

                    for (long i = 0; i < size; i++)
                    {
                        int sym = (int)br.ReadNBits(8);

                        EncodeSymbols(sym, bw);

                        Update(sym);
                    }

                    EncodeSymbols(_eof, bw);
                    bw.WriteNBits(1, ((uint)_low & 0x40000000) >> 30);
                    _underflowBits++;
                    while (_underflowBits-- > 0)
                    {
                        bw.WriteNBits(1, (~(uint)_low & 0x40000000) >> 30);
                    }

                    bw.WriteNBits(7, 0);
                }
            }
        }

        private void EncodeSymbols(int symbol, BitWriter bw)
        {
            long range = (_high - _low) + 1;
            _high = _low + (uint)(range * _lowValues[symbol + 1] / _lowValues[_symbolsCount]) - 1;
            _low = _low + (uint)(range * _lowValues[symbol] / _lowValues[_symbolsCount]);
            
            while (true)
            {
                if (MsbLow() == MsbHigh())
                {
                    bw.WriteNBits(1, MsbHigh());

                    while (_underflowBits > 0)
                    {
                        uint toWrite = (~(uint)_high & 0x80000000) >> 31;
                        bw.WriteNBits(1, toWrite);

                        _underflowBits--;
                    }
                }
                else if ((_low & 0x40000000) == 0x40000000 && (_high & 0x40000000) == 0)
                {
                    _underflowBits += 1;
                    _low &= 0x3fffffff;
                    _high |= 0x40000000;
                }
                else
                {
                    return;
                }
                ShiftEncode();
            }

        }

        private uint MsbLow()
        {
            return ((uint)_low & 0x80000000) >> 31;
        }

        private uint MsbHigh()
        {
            return ((uint)_high & 0x80000000) >> 31;
        }

        private void ShiftEncode()
        {
            _low <<= 1;
            _high <<= 1;
            _high |= 1;
        }

        #endregion
        
        #region Decode
        public void Decode(String inputFile, String outputFile)
        {
            using (BitReader br = new BitReader(inputFile))
            {
                using (BitWriter bw = new BitWriter(outputFile))
                {
                    _fileSize = (int)br.GetFileSize(inputFile) * 8;

                    int toRead = _fileSize > 32 ? 32 : _fileSize;
                    _decode = br.ReadNBits((uint)toRead);
                    _fileSize -= toRead;

                    _decode <<= (32 - toRead);

                    long range = _high - _low + 1;
                    int count = (int)((((_decode - _low) + 1) * _lowValues[_symbolsCount] - 1) / range);
                    int i = _symbolsCount - 1;
                    for (; i >= 0; --i)
                    {
                        uint foundCharacter;
                        for (foundCharacter = (uint)_symbolsCount; count < _lowValues[foundCharacter]; foundCharacter--) ;

                        if (count >= _lowValues[i] && count < _lowValues[i + 1])
                        {
                            break;
                        }
                        bw.WriteNBits(8, foundCharacter);

                        CleanBits(foundCharacter, br);
                        Update((int)foundCharacter);
                    }
                }
            }

        }

        private void CleanBits(uint symbol, BitReader br)
        {

            long range = (_high - _low) + 1;
            _high = _low + (uint)(range * _lowValues[symbol + 1] / _lowValues[_symbolsCount]) - 1;
            _low = _low + (uint)(range * _lowValues[symbol] / _lowValues[_symbolsCount]);

            while (true)
            {
                if (MsbLow() == MsbHigh())
                {

                }
                else if ((_low & 0x40000000) == 0x40000000 && (_high & 0x40000000) == 0)
                {
                    _underflowBits += 1;
                    _low &= 0x3fffffff;
                    _high |= 0x40000000;
                }
                else
                {
                    return;
                }
                ShiftDecode();
                if (_fileSize > 0)
                {
                    _decode += br.ReadNBits(1);
                    _fileSize--;
                }
            }

        }

        private uint GetCurrentModelScale(uint symbol)
        {
            long range = (long)(_high - _low) + 1;
            uint count = (uint)((((long)(_decode - _low) + 1) * _lowValues[symbol] - 1) / range);
            return count;
        }

        private void ShiftDecode()
        {
            _low <<= 1;
            _high <<= 1;
            _high |= 1;
            _decode <<= 1;
        }
        #endregion
    
    }
}
