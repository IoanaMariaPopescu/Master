﻿using ArithmeticCoder.Model;
using System;
using System.IO;
using System.Windows.Forms;

namespace ArithmeticCoder
{
    public partial class Form1 : Form
    {
        private String originalFileName;
        private String encodedFileName;
        private Coder coder;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {           
            lblOriginalFileName.Text = "";
            lblDecompressedFileName.Text = "";
        }

        #region Load Files
        private void loadFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ofdOriginalFile.Filter = "Text | *.txt";
            ofdOriginalFile.RestoreDirectory = true;
            ofdOriginalFile.Title = "Load file";
            ofdOriginalFile.InitialDirectory = @"D:\\Master\\An1\\sem 2\\Laboratoare\\ArithmeticCoder";
            if (ofdOriginalFile.ShowDialog() == DialogResult.OK)
            {
                originalFileName = ofdOriginalFile.FileName;
                lblOriginalFileName.Text = ofdOriginalFile.SafeFileName;
                rtbOriginalFile.Text = File.ReadAllText(ofdOriginalFile.FileName);
            }
        }

        private void loadCompressedFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ofdCompressedFile.Filter = "Text | *.out";
            ofdCompressedFile.Title = "Load compressed file";
            ofdCompressedFile.RestoreDirectory = true;
            ofdCompressedFile.InitialDirectory = @"D:\\Master\\An1\\sem 2\\Laboratoare\\ArithmeticCoder";
            if (ofdCompressedFile.ShowDialog() == DialogResult.OK)
            {
                encodedFileName = ofdCompressedFile.FileName;
                lblOriginalFileName.Text = ofdCompressedFile.SafeFileName;
                rtbOriginalFile.Clear();
                rtbCompressedFile.Clear();
                rtbOriginalFile.Text = File.ReadAllText(ofdCompressedFile.FileName);
            }
        }
        #endregion

        #region Encode Decode
        private void btnEncode_Click(object sender, EventArgs e)
        {
            coder = new Coder(256);
            encodedFileName = originalFileName + ".out";
            coder.Encode(originalFileName, encodedFileName);
            rtbCompressedFile.Clear();
            rtbCompressedFile.Text = File.ReadAllText(encodedFileName);
            lblDecompressedFileName.Text = encodedFileName;

        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            coder = new Coder(256);
            String outputFileName = "result.out";
            coder.Decode(encodedFileName, outputFileName);
            rtbCompressedFile.Clear();
            rtbCompressedFile.Text = File.ReadAllText(originalFileName);
            lblDecompressedFileName.Text = originalFileName;

        }
        #endregion
    }
}
