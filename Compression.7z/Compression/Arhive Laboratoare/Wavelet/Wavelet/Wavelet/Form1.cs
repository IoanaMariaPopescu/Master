﻿using System;
using System.Windows.Forms;
using Wavelet.Controller;

namespace Wavelet
{
    public partial class MainForm : Form
    {
        Functions controller = new Functions();
        Analyzis analysis = new Analyzis();
        Synthesizer synthesizer = new Synthesizer();

        public MainForm()
        {
            InitializeComponent();
        }


        private void MainForm_Load(object sender, EventArgs e)
        {
            txbX.Text = "256";
            txbY.Text = "256";
            txbOffset.Text = "128";
            txbScale.Text = "20";
            lblMinResult.Text = "0";
            lblMaxResult.Text = "0";
        }

        private void btnLoadBmp_Click(object sender, EventArgs e) => controller.loadImage(ofdOriginalImage, "BMP | *.bmp", originalImagePictureBox);

        private void btnLoadWvl_Click(object sender, EventArgs e) => controller.loadImage(ofdOriginalImage, "WVL | *.wvl", waveletPictureBox);

        private void btnSaveWvl_Click(object sender, EventArgs e) => controller.saveImage(waveletPictureBox,saveFileDialog);

        private void btnAnalyze_Click(object sender, EventArgs e) => analysis.analyseClick(analysis, numericUpDown1, waveletPictureBox, originalImagePictureBox, lblMinResult, lblMaxResult);

        private void btnSynthesize_Click(object sender, EventArgs e) => synthesizer.synthesizerClick(synthesizer, numericUpDown1, waveletPictureBox, originalImagePictureBox, lblMinResult, lblMaxResult);

        private void btnVisualizeWvl_Click(object sender, EventArgs e) => controller.refreshWavelet(waveletPictureBox, txbScale, txbOffset, txbX, txbY);

    }
}
