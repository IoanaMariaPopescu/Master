﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Wavelet.Controller
{
    public class Synthesizer
    {
        public Functions controller = new Functions();
        public Analyzis analysis = new Analyzis();

        public static double[] synthesisL = {0.000000000000, -0.091271763114, -0.057543526229, 0.591271763114, 1.115087052457,
            0.591271763114, -0.057543526229, -0.091271763114, 0.000000000000};
        public static double[] synthesisH = {0.026748757411, 0.016864118443, -0.078223266529, -0.266864118443, 0.602949018236,
            -0.266864118443, -0.078223266529, 0.016864118443, 0.026748757411};

        public double[,] matrix;

        public double[,] getMatrix()
        {
            return matrix;
        }

        public void setMatrix(double[,] matrix)
        {
            this.matrix = matrix;
        }
        
        public void dewaveletize(int levels)
        {
            int length = 512;
            length /= (int)Math.Pow(2, levels - 1);
            for (int k = 0; k < levels; ++k)
            {
                for (int j = 0; j < length; ++j)
                {
                    synthesizeV(j, length);
                }
                for (int i = 0; i < length; ++i)
                {
                    synthesizeH(i, length);
                }
                length *= 2;
            }
        }

        public void synthesizeV(int col, int length)
        {
            double[] array = new double[length];
            for (int i = 0; i < length; ++i)
            {
                array[i] = matrix[i,col];
            }
            double[] unwavelet = synthesize(array);
            for (int i = 0; i < length; ++i)
            {
                matrix[i,col] = unwavelet[i];
            }
        }

        public void synthesizeH(int row, int length)
        {
            double[] array = new double[length];
            for (int j = 0; j < length; ++j)
            {
                array[j] = matrix[row,j];
            }
            double[] unwavelet = synthesize(array);
            for (int j = 0; j < length; ++j)
            {
                matrix[row,j] = unwavelet[j];
            }
        }

        public double[] synthesize(double[] array)
        {
            double[] arrayL = new double[array.Length];
            double[] arrayH = new double[array.Length];

            for (int i = 0; i < array.Length / 2; ++i)
            {
                arrayL[2 * i] = array[i];
            }
            for (int i = array.Length / 2; i < array.Length; ++i)
            {
                arrayH[(i - array.Length / 2) * 2 + 1] = array[i];
            }

            double[] low = controller.convolution(arrayL, synthesisL);
            double[] high = controller.convolution(arrayH, synthesisH);

            double[] unwavelet = new double[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                unwavelet[i] = low[i] + high[i];
            }

            return unwavelet;
        }

        public void synthesizerClick(Synthesizer synthesizer, NumericUpDown numericUpDown1, PictureBox waveletPictureBox, PictureBox originalImagePictureBox, Label lblMinResult, Label lblMaxResult)
        {
            int level = Convert.ToInt32(Math.Round(numericUpDown1.Value, 0));
            matrix = controller.adaptImageToDoubleMatrix((Bitmap)waveletPictureBox.Image);
            synthesizer.dewaveletize(level);

            Bitmap scaledImage = controller.adaptDoubleMatrixToImage(matrix);
            waveletPictureBox.Image = scaledImage;

            Bitmap originalImage = (Bitmap)originalImagePictureBox.Image;

            controller.calculateError(originalImage, scaledImage, lblMinResult, lblMaxResult);
        }
    }
}
