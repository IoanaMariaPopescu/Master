﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Wavelet.Controller
{
    public class Analyzis
    {
        Functions controller = new Functions();

        public static double[] analysisL = {0.026748757411, -0.016864118443, -0.078223266529, 0.266864118443, 0.602949018236,
            0.266864118443, -0.078223266529, -0.016864118443, 0.026748757411};
        public static double[] analysisH = {0.000000000000, 0.091271763114, -0.057543526229, -0.591271763114, 1.115087052457,
            -0.591271763114, -0.057543526229, 0.091271763114, 0.000000000000};

        private double[,] matrix;

        public double[,] getMatrix()
        {
            return matrix;
        }

        public void setMatrix(double[,] matrix)
        {
            this.matrix = matrix;
        }

        public void waveletize(int levels)
        {
            int length = 512;
            for (int k = 0; k < levels; ++k)
            {
                for (int i = 0; i < length; ++i)
                {
                    analyzeH(i, length);
                }
                for (int j = 0; j < length; ++j)
                {
                    analyzeV(j, length);
                }
                length /= 2;
            }
        }

        public void analyzeH(int line, int length)
        {
            double[] array = new double[length];
            for (int j = 0; j < length; ++j)
            {
                array[j] = matrix[line,j];
            }
            double[] wavelet = analyze(array);
            for (int j = 0; j < length; ++j)
            {
                matrix[line,j] = wavelet[j];
            }
        }

        public void analyzeV(int col, int length)
        {
            double[] array = new double[length];
            for (int i = 0; i < length; ++i)
            {
                array[i] = matrix[i,col];
            }
            double[] wavelet = analyze(array);
            for (int i = 0; i < length; ++i)
            {
                matrix[i,col] = wavelet[i];
            }
        }

        public double[] analyze(double[] array)
        {
            double[] low = controller.convolution(array, analysisL);
            double[] high = controller.convolution(array, analysisH);

            double[] wavelet = new double[array.Length];
            for (int i = 0; i < array.Length / 2; i++)
            {
                wavelet[i] = low[2 * i];
                wavelet[array.Length / 2 + i] = high[1 + 2 * i];
            }

            return wavelet;
        }

        public void analyseClick(Analyzis analysis, NumericUpDown numericUpDown1, PictureBox waveletPictureBox, PictureBox originalImagePictureBox, Label lblMinResult, Label lblMaxResult)
        {
            int level = Convert.ToInt32(Math.Round(numericUpDown1.Value, 0));

            Bitmap originalImage = (Bitmap)originalImagePictureBox.Image;
            matrix = controller.adaptImageToDoubleMatrix(originalImage);
            analysis.waveletize(level);

            Bitmap scaledImage = controller.adaptDoubleMatrixToImage(matrix);
            waveletPictureBox.Image = scaledImage;
            controller.calculateError(originalImage, scaledImage, lblMinResult, lblMaxResult);
        }
    }
}
