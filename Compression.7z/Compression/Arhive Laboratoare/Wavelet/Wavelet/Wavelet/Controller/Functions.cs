﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Wavelet.Controller
{
    public class Functions
    {
        public void loadImage(OpenFileDialog ofd, String imageSuffix, PictureBox pictureBox)
        {
            ofd.Filter = imageSuffix;
            DialogResult dialogResult = ofd.ShowDialog();
            ofd.InitialDirectory = @"D:\\Master\\An1\\sem 2\\Laboratoare";
            if (dialogResult == DialogResult.OK)
            {
                string inputFile = ofd.FileName;
                Bitmap bitmap = new Bitmap(inputFile);
                pictureBox.Image = bitmap;
            }
        }

        public void saveImage(PictureBox pictureBox, SaveFileDialog saveFileDialog)
        {
            saveFileDialog.InitialDirectory = "@D:\\Master\\An1\\sem 2\\Laboratoare\\Wavelet\\Wavelet\\";
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.FileName = "*.wvl";
            saveFileDialog.DefaultExt = "wvl";
            saveFileDialog.Filter = "wavelet files (*.wvl)|*.wvl ";
            
            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image.Save(@"D:\\Master\\An1\\sem 2\\Laboratoare\\Wavelet\\Wavelet\\test.wvl");
                MessageBox.Show("Image was successfully saved.");
            }
                 
        }

        public void calculateError(Bitmap source, Bitmap destination, Label lblMinResult, Label lblMaxResult)
        {
            int min = 256;
            int max = -1;

            for (int i = 0; i < 512; i++)
            {
                for (int j = 0; j < 512; ++j)
                {
                    Color colorSource = source.GetPixel(i, j);
                    Color colorDestination = destination.GetPixel(i, j);
                    int sourceValue = colorSource.B;
                    int destinationValue = colorDestination.B;
                    int diff = Math.Abs(sourceValue - destinationValue);
                    if (diff < min)
                    {
                        min = diff;
                    }
                    if (diff > max)
                    {
                        max = diff;
                    }
                }

                lblMinResult.Text = min.ToString();
                lblMaxResult.Text = max.ToString();
            }
        }

        public double[,] adaptImageToDoubleMatrix(Bitmap sourceImage)
        {
            double[,] matrix = new double[512,512];

            for (int x = 0; x < 512; ++x)
            {
                for (int y = 0; y < 512; ++y)
                {
                    Color color = sourceImage.GetPixel(x, y);
                    matrix[y, x] = color.B;
                }
            }            

            return matrix;
        }

        public Bitmap adaptDoubleMatrixToImage(double[,] matrix)
        {
            Bitmap image = new Bitmap(512, 512);

            for (int x = 0; x < 512; ++x)
            {
                for (int y = 0; y < 512; ++y)
                {
                    double val = matrix[x,y];
                    int iVal = (int)Math.Round(val);
                    iVal = Math.Max(Math.Min(iVal, 255), 0);
                    Color color = Color.FromArgb(iVal, iVal, iVal);
                    image.SetPixel(y, x, color);
                }
            }
            return image;
        }

        public double[] convolution(double[] array, double[] analysis)
        {
            double[] convoluted = new double[array.Length];

            for (int i = 0; i < array.Length; ++i)
            {
                double sum = 0;
                int offset = analysis.Length / 2;
                for (int j = -offset; j <= offset; ++j)
                {
                    int index = 0;
                    if (i + j < 0)
                    {
                        index = Math.Abs(i + j);
                    }
                    else if (i + j >= array.Length)
                    {
                        index = array.Length - 1 - (i + j - array.Length + 1);
                    }
                    else
                    {
                        index = i + j;
                    }
                    sum += array[index] * analysis[j + offset];
                }
                convoluted[i] = sum;
            }

            return convoluted;
        }

        public void refreshWavelet(PictureBox waveletPictureBox, TextBox txbScale, TextBox txbOffset, TextBox txbX, TextBox txbY)
        {

            Bitmap scaledImage = (Bitmap)waveletPictureBox.Image;

            int scale = Convert.ToInt32(txbScale.Text);
            int offset = Convert.ToInt32(txbOffset.Text);
            int x = Convert.ToInt32(txbX.Text);
            int y = Convert.ToInt32(txbY.Text);

            for (int yy = 0; yy < 512; ++yy)
            {
                for (int xx = 0; xx < 512; ++xx)
                {
                    if (xx >= x || yy >= y)
                    {
                        Color oldColor = scaledImage.GetPixel(xx, yy);
                        int val = oldColor.B;
                        val = scale * val + offset;
                        if (val > 255)
                        {
                            val = 255;
                        }
                        Color newColor = Color.FromArgb(val, val, val);
                        scaledImage.SetPixel(xx, yy, newColor);
                    }

                }
            }

            waveletPictureBox.Refresh();
        }
    
    }
}
    

