﻿namespace Wavelet
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalImagePictureBox = new System.Windows.Forms.PictureBox();
            this.waveletPictureBox = new System.Windows.Forms.PictureBox();
            this.btnLoadBmp = new System.Windows.Forms.Button();
            this.btnLoadWvl = new System.Windows.Forms.Button();
            this.btnSaveWvl = new System.Windows.Forms.Button();
            this.lblLevels = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btnAnalyze = new System.Windows.Forms.Button();
            this.btnSynthesize = new System.Windows.Forms.Button();
            this.lblMaxResult = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMinResult = new System.Windows.Forms.Label();
            this.btnVisualizeWvl = new System.Windows.Forms.Button();
            this.lblScale = new System.Windows.Forms.Label();
            this.lblOffset = new System.Windows.Forms.Label();
            this.txbScale = new System.Windows.Forms.TextBox();
            this.txbOffset = new System.Windows.Forms.TextBox();
            this.txbX = new System.Windows.Forms.TextBox();
            this.txbY = new System.Windows.Forms.TextBox();
            this.lblX = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.ofdOriginalImage = new System.Windows.Forms.OpenFileDialog();
            this.ofdWVLImage = new System.Windows.Forms.OpenFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.originalImagePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waveletPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // originalImagePictureBox
            // 
            this.originalImagePictureBox.Location = new System.Drawing.Point(12, 12);
            this.originalImagePictureBox.Name = "originalImagePictureBox";
            this.originalImagePictureBox.Size = new System.Drawing.Size(686, 635);
            this.originalImagePictureBox.TabIndex = 0;
            this.originalImagePictureBox.TabStop = false;
            // 
            // waveletPictureBox
            // 
            this.waveletPictureBox.Location = new System.Drawing.Point(764, 12);
            this.waveletPictureBox.Name = "waveletPictureBox";
            this.waveletPictureBox.Size = new System.Drawing.Size(664, 635);
            this.waveletPictureBox.TabIndex = 1;
            this.waveletPictureBox.TabStop = false;
            // 
            // btnLoadBmp
            // 
            this.btnLoadBmp.Location = new System.Drawing.Point(317, 694);
            this.btnLoadBmp.Name = "btnLoadBmp";
            this.btnLoadBmp.Size = new System.Drawing.Size(87, 37);
            this.btnLoadBmp.TabIndex = 2;
            this.btnLoadBmp.Text = "Load bmp";
            this.btnLoadBmp.UseVisualStyleBackColor = true;
            this.btnLoadBmp.Click += new System.EventHandler(this.btnLoadBmp_Click);
            // 
            // btnLoadWvl
            // 
            this.btnLoadWvl.Location = new System.Drawing.Point(783, 694);
            this.btnLoadWvl.Name = "btnLoadWvl";
            this.btnLoadWvl.Size = new System.Drawing.Size(87, 37);
            this.btnLoadWvl.TabIndex = 4;
            this.btnLoadWvl.Text = "Load wvl";
            this.btnLoadWvl.UseVisualStyleBackColor = true;
            this.btnLoadWvl.Click += new System.EventHandler(this.btnLoadWvl_Click);
            // 
            // btnSaveWvl
            // 
            this.btnSaveWvl.Location = new System.Drawing.Point(925, 696);
            this.btnSaveWvl.Name = "btnSaveWvl";
            this.btnSaveWvl.Size = new System.Drawing.Size(87, 37);
            this.btnSaveWvl.TabIndex = 5;
            this.btnSaveWvl.Text = "Save wvl";
            this.btnSaveWvl.UseVisualStyleBackColor = true;
            this.btnSaveWvl.Click += new System.EventHandler(this.btnSaveWvl_Click);
            // 
            // lblLevels
            // 
            this.lblLevels.AutoSize = true;
            this.lblLevels.Location = new System.Drawing.Point(36, 704);
            this.lblLevels.Name = "lblLevels";
            this.lblLevels.Size = new System.Drawing.Size(49, 17);
            this.lblLevels.TabIndex = 6;
            this.lblLevels.Text = "Levels";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(158, 704);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(53, 22);
            this.numericUpDown1.TabIndex = 7;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnAnalyze
            // 
            this.btnAnalyze.Location = new System.Drawing.Point(36, 759);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(87, 37);
            this.btnAnalyze.TabIndex = 8;
            this.btnAnalyze.Text = "Analyze";
            this.btnAnalyze.UseVisualStyleBackColor = true;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);
            // 
            // btnSynthesize
            // 
            this.btnSynthesize.Location = new System.Drawing.Point(185, 759);
            this.btnSynthesize.Name = "btnSynthesize";
            this.btnSynthesize.Size = new System.Drawing.Size(123, 37);
            this.btnSynthesize.TabIndex = 9;
            this.btnSynthesize.Text = "Synthesize";
            this.btnSynthesize.UseVisualStyleBackColor = true;
            this.btnSynthesize.Click += new System.EventHandler(this.btnSynthesize_Click);
            // 
            // lblMaxResult
            // 
            this.lblMaxResult.AutoSize = true;
            this.lblMaxResult.Location = new System.Drawing.Point(616, 740);
            this.lblMaxResult.Name = "lblMaxResult";
            this.lblMaxResult.Size = new System.Drawing.Size(46, 17);
            this.lblMaxResult.TabIndex = 10;
            this.lblMaxResult.Text = "label1";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(448, 706);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(40, 17);
            this.lblError.TabIndex = 11;
            this.lblError.Text = "Error";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(526, 705);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(30, 17);
            this.lblMin.TabIndex = 12;
            this.lblMin.Text = "Min";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(526, 740);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(33, 17);
            this.lblMax.TabIndex = 13;
            this.lblMax.Text = "Max";
            // 
            // lblMinResult
            // 
            this.lblMinResult.AutoSize = true;
            this.lblMinResult.Location = new System.Drawing.Point(616, 704);
            this.lblMinResult.Name = "lblMinResult";
            this.lblMinResult.Size = new System.Drawing.Size(46, 17);
            this.lblMinResult.TabIndex = 14;
            this.lblMinResult.Text = "label2";
            // 
            // btnVisualizeWvl
            // 
            this.btnVisualizeWvl.Location = new System.Drawing.Point(783, 771);
            this.btnVisualizeWvl.Name = "btnVisualizeWvl";
            this.btnVisualizeWvl.Size = new System.Drawing.Size(206, 37);
            this.btnVisualizeWvl.TabIndex = 15;
            this.btnVisualizeWvl.Text = "Visualize Wavelet";
            this.btnVisualizeWvl.UseVisualStyleBackColor = true;
            this.btnVisualizeWvl.Click += new System.EventHandler(this.btnVisualizeWvl_Click);
            // 
            // lblScale
            // 
            this.lblScale.AutoSize = true;
            this.lblScale.Location = new System.Drawing.Point(1130, 706);
            this.lblScale.Name = "lblScale";
            this.lblScale.Size = new System.Drawing.Size(43, 17);
            this.lblScale.TabIndex = 16;
            this.lblScale.Text = "Scale";
            // 
            // lblOffset
            // 
            this.lblOffset.AutoSize = true;
            this.lblOffset.Location = new System.Drawing.Point(1130, 776);
            this.lblOffset.Name = "lblOffset";
            this.lblOffset.Size = new System.Drawing.Size(46, 17);
            this.lblOffset.TabIndex = 17;
            this.lblOffset.Text = "Offset";
            // 
            // txbScale
            // 
            this.txbScale.Location = new System.Drawing.Point(1180, 706);
            this.txbScale.Name = "txbScale";
            this.txbScale.Size = new System.Drawing.Size(68, 22);
            this.txbScale.TabIndex = 18;
            // 
            // txbOffset
            // 
            this.txbOffset.Location = new System.Drawing.Point(1182, 776);
            this.txbOffset.Name = "txbOffset";
            this.txbOffset.Size = new System.Drawing.Size(68, 22);
            this.txbOffset.TabIndex = 19;
            // 
            // txbX
            // 
            this.txbX.Location = new System.Drawing.Point(1341, 701);
            this.txbX.Name = "txbX";
            this.txbX.Size = new System.Drawing.Size(48, 22);
            this.txbX.TabIndex = 20;
            // 
            // txbY
            // 
            this.txbY.Location = new System.Drawing.Point(1341, 778);
            this.txbY.Name = "txbY";
            this.txbY.Size = new System.Drawing.Size(48, 22);
            this.txbY.TabIndex = 21;
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(1321, 704);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(14, 17);
            this.lblX.TabIndex = 22;
            this.lblX.Text = "x";
            // 
            // lblY
            // 
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(1321, 781);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(15, 17);
            this.lblY.TabIndex = 23;
            this.lblY.Text = "y";
            // 
            // ofdOriginalImage
            // 
            this.ofdOriginalImage.FileName = "openFileDialog1";
            // 
            // ofdWVLImage
            // 
            this.ofdWVLImage.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Location = new System.Drawing.Point(723, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 854);
            this.panel1.TabIndex = 24;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1440, 853);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.txbY);
            this.Controls.Add(this.txbX);
            this.Controls.Add(this.txbOffset);
            this.Controls.Add(this.txbScale);
            this.Controls.Add(this.lblOffset);
            this.Controls.Add(this.lblScale);
            this.Controls.Add(this.btnVisualizeWvl);
            this.Controls.Add(this.lblMinResult);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.lblMaxResult);
            this.Controls.Add(this.btnSynthesize);
            this.Controls.Add(this.btnAnalyze);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.lblLevels);
            this.Controls.Add(this.btnSaveWvl);
            this.Controls.Add(this.btnLoadWvl);
            this.Controls.Add(this.btnLoadBmp);
            this.Controls.Add(this.waveletPictureBox);
            this.Controls.Add(this.originalImagePictureBox);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Wavelet";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.originalImagePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waveletPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox originalImagePictureBox;
        private System.Windows.Forms.PictureBox waveletPictureBox;
        private System.Windows.Forms.Button btnLoadBmp;
        private System.Windows.Forms.Button btnLoadWvl;
        private System.Windows.Forms.Button btnSaveWvl;
        private System.Windows.Forms.Label lblLevels;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnAnalyze;
        private System.Windows.Forms.Button btnSynthesize;
        private System.Windows.Forms.Label lblMaxResult;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.Label lblMinResult;
        private System.Windows.Forms.Button btnVisualizeWvl;
        private System.Windows.Forms.Label lblScale;
        private System.Windows.Forms.Label lblOffset;
        private System.Windows.Forms.TextBox txbScale;
        private System.Windows.Forms.TextBox txbOffset;
        private System.Windows.Forms.TextBox txbX;
        private System.Windows.Forms.TextBox txbY;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.OpenFileDialog ofdOriginalImage;
        private System.Windows.Forms.OpenFileDialog ofdWVLImage;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

