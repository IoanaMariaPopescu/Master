﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wavelet
{
    public static class Extensions
    {
        public static byte NormalizePixelValue(this byte val)
        {
            if (val > 255) return 255;
            if (val < 0) return 0;
            return val;
        }

        public static double NormalizePixelValue(this double val)
        {
            if (val > 255) return 255;
            if (val < 0) return 0;
            return val;
        }
    }
}
