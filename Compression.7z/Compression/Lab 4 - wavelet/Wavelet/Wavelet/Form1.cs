﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Wavelet.Constants;

namespace Wavelet
{
    public partial class WaveletForm : Form
    {
        byte[,] originalImageMatrix;
        double[,] synthesizedImageMatrix;
        double[,] reconstructedImageMatrix;
        public WaveletForm()
        {
            InitializeComponent();
            originalImageMatrix = new byte[ImageSize, ImageSize];
            synthesizedImageMatrix = new double[ImageSize, ImageSize];
            reconstructedImageMatrix = new double[ImageSize, ImageSize];
        }

        private void loadOriginalButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Choose Picture";
            dialog.Filter = "BMP images|*.bmp";
            dialog.InitialDirectory = string.Format(@"{0}\Images", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Bitmap bitmap = new Bitmap(dialog.FileName);

                for (int i = 0; i < ImageSize; i++)
                {
                    for (int j = 0; j < ImageSize; j++)
                    {
                        originalImageMatrix[i, j] = bitmap.GetPixel(i, j).R;
                        synthesizedImageMatrix[i, j] = bitmap.GetPixel(i, j).R;
                    }
                }

                originalPictureBox.Image = bitmap;
            }
        }

        private void AnalysisVertical(int line, int length)
        {
            double[] extendedLine = new double[length + 8];
            double[] analysisLow = new double[length];
            double[] analysisHigh = new double[length];

            for (int i = 0; i < length; i++)
            {
                extendedLine[i + 4] = synthesizedImageMatrix[line, i];
            }

            for (int i = 0; i <= 3; i++)
            {
                extendedLine[i] = extendedLine[8 - i];
                extendedLine[length + 4 + i] = extendedLine[length + 2 - i];
            }

            for (int i = 4; i < length + 4; i++)
            {
                for (int j = 0; j <= 8; j++)
                {
                    analysisLow[i - 4] += AnalysisL[j] * extendedLine[i - (j - 4)];
                    analysisHigh[i - 4] += AnalysisH[j] * extendedLine[i - (j - 4)];
                }
            }

            double[] downSampleLow = new double[length];
            double[] downSampleHigh = new double[length];
            Array.Clear(downSampleLow, 0, length);
            Array.Clear(downSampleHigh, 0, length);

            for (int i = 0; i < length; i++)
            {
                if (i % 2 == 0)
                {
                    downSampleLow[i] = analysisLow[i];
                }
                else
                {
                    downSampleHigh[i] = analysisHigh[i];
                }
            }

            double[] rearrange = new double[length];
            for (int i = 0; i < length / 2; i++)
            {
                rearrange[i] = downSampleLow[2 * i];
                rearrange[i + length / 2] = downSampleHigh[2 * i + 1];
            }

            for (int i = 0; i < length; i++)
            {
                synthesizedImageMatrix[line, i] = rearrange[i];
            }
        }

        private void AnalysisHorizontal(int line, int length)
        {
            double[] extendedLine = new double[length + 8];
            double[] analysisLow = new double[length];
            double[] analysisHigh = new double[length];

            for (int i = 0; i < length; i++)
            {
                extendedLine[i + 4] = synthesizedImageMatrix[i, line];
            }

            for (int i = 0; i <= 3; i++)
            {
                extendedLine[i] = extendedLine[8 - i];
                extendedLine[length + 4 + i] = extendedLine[length + 2 - i];
            }

            for (int i = 4; i < length + 4; i++)
            {
                for (int j = 0; j <= 8; j++)
                {
                    analysisLow[i - 4] += AnalysisL[j] * extendedLine[i - (j - 4)];
                    analysisHigh[i - 4] += AnalysisH[j] * extendedLine[i - (j - 4)];
                }
            }

            double[] downSampleLow = new double[length];
            double[] downSampleHigh = new double[length];
            Array.Clear(downSampleLow, 0, length);
            Array.Clear(downSampleHigh, 0, length);

            for (int i = 0; i < length; i++)
            {
                if (i % 2 == 0)
                {
                    downSampleLow[i] = analysisLow[i];
                }
                else
                {
                    downSampleHigh[i] = analysisHigh[i];
                }
            }

            double[] rearrange = new double[length];
            for (int i = 0; i < length / 2; i++)
            {
                rearrange[i] = downSampleLow[2 * i];
                rearrange[i + length / 2] = downSampleHigh[2 * i + 1];
            }

            for (int i = 0; i < length; i++)
            {
                synthesizedImageMatrix[i, line] = rearrange[i];
            }
        }

        private void SynthesisVertical(int line, int length)
        {
            double[] reconstructed = new double[length];
            double[] synthesisLow = new double[length];
            double[] synthesisHigh = new double[length];
            double[] upSampleLow = new double[length];
            double[] upSampleHigh = new double[length];
            double[] extendedUpSampleLow = new double[length + 8];
            double[] extendedUpSampleHigh = new double[length + 8];

            Array.Clear(upSampleLow, 0, length);
            Array.Clear(upSampleHigh, 0, length);
            Array.Clear(extendedUpSampleLow, 0, length);
            Array.Clear(extendedUpSampleHigh, 0, length);
            for (int i = 0; i < length / 2; i++)
            {
                upSampleLow[2 * i] = synthesizedImageMatrix[line, i];
                upSampleHigh[2 * i + 1] = synthesizedImageMatrix[line, i + length / 2];
            }

            for (int i = 0; i < length; i++)
            {
                extendedUpSampleLow[i + 4] = upSampleLow[i];
            }
            extendedUpSampleLow[0] = extendedUpSampleLow[8];
            extendedUpSampleLow[2] = extendedUpSampleLow[6];
            extendedUpSampleLow[length + 4] = extendedUpSampleLow[length + 2];
            extendedUpSampleLow[length + 6] = extendedUpSampleLow[length];

            for (int i = 0; i < length; i++)
            {
                extendedUpSampleHigh[i + 4] = upSampleHigh[i];
            }

            extendedUpSampleHigh[1] = extendedUpSampleHigh[7];
            extendedUpSampleHigh[3] = extendedUpSampleHigh[5];

            extendedUpSampleHigh[length + 5] = extendedUpSampleHigh[length + 1];
            extendedUpSampleHigh[length + 7] = extendedUpSampleHigh[length - 1];

            for (int i = 4; i < length + 4; i++)
            {
                for (int j = 0; j <= 8; j++)
                {
                    synthesisLow[i - 4] += SynthesisL[j] * extendedUpSampleLow[i - (j - 4)];
                    synthesisHigh[i - 4] += SynthesisH[j] * extendedUpSampleHigh[i - (j - 4)];
                }
            }

            for (int i = 0; i < length; i++)
            {
                if (length == ImageSize)
                {
                    reconstructed[i] = Math.Round(synthesisLow[i] + synthesisHigh[i]);
                }
                else
                {
                    reconstructed[i] = synthesisLow[i] + synthesisHigh[i];
                }

                reconstructedImageMatrix[line, i] = synthesizedImageMatrix[line, i] = reconstructed[i];
            }
        }

        private void SynthesisHorizontal(int line, int length)
        {
            double[] reconstructed = new double[length];
            double[] synthesisLow = new double[length];
            double[] synthesisHigh = new double[length];
            double[] upSampleLow = new double[length];
            double[] upSampleHigh = new double[length];
            double[] extendedUpSampleLow = new double[length + 8];
            double[] extendedUpSampleHigh = new double[length + 8];

            Array.Clear(upSampleLow, 0, length);
            Array.Clear(upSampleHigh, 0, length);
            Array.Clear(extendedUpSampleLow, 0, length);
            Array.Clear(extendedUpSampleHigh, 0, length);
            for (int i = 0; i < length / 2; i++)
            {
                upSampleLow[2 * i] = synthesizedImageMatrix[i, line];
            }

            for (int i = 0; i < length / 2; i++)
            {
                upSampleHigh[2 * i + 1] = synthesizedImageMatrix[i + length / 2, line];
            }

            for (int i = 0; i < length; i++)
            {
                extendedUpSampleLow[i + 4] = upSampleLow[i];
            }
            extendedUpSampleLow[0] = extendedUpSampleLow[8];
            extendedUpSampleLow[2] = extendedUpSampleLow[6];
            extendedUpSampleLow[length + 4] = extendedUpSampleLow[length + 2];
            extendedUpSampleLow[length + 6] = extendedUpSampleLow[length];

            for (int i = 0; i < length; i++)
            {
                extendedUpSampleHigh[i + 4] = upSampleHigh[i];
            }

            extendedUpSampleHigh[1] = extendedUpSampleHigh[7];
            extendedUpSampleHigh[3] = extendedUpSampleHigh[5];

            extendedUpSampleHigh[length + 5] = extendedUpSampleHigh[length + 1];
            extendedUpSampleHigh[length + 7] = extendedUpSampleHigh[length - 1];

            for (int i = 4; i < length + 4; i++)
            {
                for (int j = 0; j <= 8; j++)
                {
                    synthesisLow[i - 4] += SynthesisL[j] * extendedUpSampleLow[i - (j - 4)];
                    synthesisHigh[i - 4] += SynthesisH[j] * extendedUpSampleHigh[i - (j - 4)];
                }
            }

            for (int i = 0; i < length; i++)
            {
                reconstructed[i] = synthesisLow[i] + synthesisHigh[i];
                reconstructedImageMatrix[i, line] = synthesizedImageMatrix[i, line] = reconstructed[i];
            }
        }

        private void anHoriz1button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 2;
            for (int i = 0; i < ImageSize; i++)
            {
                AnalysisHorizontal(i, ImageSize);
            }
        }

        private void anVert1button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 2;
            for (int i = 0; i < ImageSize; i++)
            {
                AnalysisVertical(i, ImageSize);
            }
        }

        private void synHoriz1button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize - 1;
            for (int i = 0; i < ImageSize; i++)
            {
                SynthesisHorizontal(i, ImageSize);
            }
        }

        private void synVert1button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize - 1;
            for (int i = 0; i < ImageSize; i++)
            {
                SynthesisVertical(i, ImageSize);
            }
        }

        private void testErrorButton_Click(object sender, EventArgs e)
        {
            double min, max, dif;
            min = double.MaxValue;
            max = double.MinValue;

            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    dif = originalImageMatrix[i, j] - reconstructedImageMatrix[i, j];
                    if (dif < min) min = dif;
                    if (dif > max) max = dif;
                }
            }

            minErrorTextBox.Text = min.ToString();
            maxErrorTextBox.Text = max.ToString();
        }

        private void VisualizeButton_Click(object sender, EventArgs e)
        {
            waveletPictureBox.Image = new Bitmap(ImageSize, ImageSize);

            for (int i = 0; i < ImageSize; i++)
            {
                for (int j = 0; j < ImageSize; j++)
                {
                    if (i <= (int)yNumericUpDown.Value && j <= (int)xNumericUpDown.Value)
                    {
                        ((Bitmap)waveletPictureBox.Image)
                            .SetPixel(i, j, Color.FromArgb((int)synthesizedImageMatrix[i, j].NormalizePixelValue(), (int)synthesizedImageMatrix[i, j].NormalizePixelValue(), (int)synthesizedImageMatrix[i, j].NormalizePixelValue()));
                    }
                    else
                    {
                        int scaledValue = (int)scaleNumericUpDown.Value * (int)Math.Round(synthesizedImageMatrix[i, j]) + (int)offsetNumericUpDown.Value;
                        if (scaledValue > 255) scaledValue = 255;
                        if (scaledValue < 0) scaledValue = 0;
                        ((Bitmap)waveletPictureBox.Image).SetPixel(i, j, Color.FromArgb(scaledValue, scaledValue, scaledValue));
                    }
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefile = new SaveFileDialog();
            savefile.FileName = "wavelet.wvl";
            savefile.Filter = "Wavelet files|*.wvl";
            savefile.InitialDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (savefile.ShowDialog() == DialogResult.OK)
            {
                FileStream fileStream = new FileStream(savefile.FileName, FileMode.Create);
                using (BinaryWriter bw = new BinaryWriter(fileStream))
                {
                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {
                            bw.Write(synthesizedImageMatrix[i, j]);
                        }
                    }

                }
            }
        }

        private void loadWaveletButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Choose Wavelet File";
            dialog.Filter = "Wavelet Files|*.wvl";
            dialog.InitialDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                FileStream fileStream = new FileStream(dialog.FileName, FileMode.Open);
                using (BinaryReader br = new BinaryReader(fileStream))
                {
                    for (int i = 0; i < ImageSize; i++)
                    {
                        for (int j = 0; j < ImageSize; j++)
                        {
                            synthesizedImageMatrix[i, j] = br.ReadDouble();
                        }
                    }
                }
            }
        }

        private void anHoriz2button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 4;
            for (int i = 0; i < ImageSize / 2; i++)
            {
                AnalysisHorizontal(i, ImageSize / 2);
            }
        }

        private void anHoriz3button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 8;
            for (int i = 0; i < ImageSize / 4; i++)
            {
                AnalysisHorizontal(i, ImageSize / 4);
            }
        }

        private void anHoriz4button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 16;
            for (int i = 0; i < ImageSize / 8; i++)
            {
                AnalysisHorizontal(i, ImageSize / 8);
            }
        }

        private void anHoriz5button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 32;
            for (int i = 0; i < ImageSize / 16; i++)
            {
                AnalysisHorizontal(i, ImageSize / 16);
            }
        }

        private void anVert2button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 4;
            for (int i = 0; i < ImageSize / 2; i++)
            {
                AnalysisVertical(i, ImageSize / 2);
            }
        }

        private void anVert3button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 8;
            for (int i = 0; i < ImageSize / 4; i++)
            {
                AnalysisVertical(i, ImageSize / 4);
            }
        }

        private void anVert4button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 16;
            for (int i = 0; i < ImageSize / 8; i++)
            {
                AnalysisVertical(i, ImageSize / 8);
            }
        }

        private void anVert5button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 32;
            for (int i = 0; i < ImageSize / 16; i++)
            {
                AnalysisVertical(i, ImageSize / 16);
            }
        }

        private void synHoriz2button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 2;
            for (int i = 0; i < ImageSize / 2; i++)
            {
                SynthesisHorizontal(i, ImageSize / 2);
            }
        }

        private void synVert2button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 2;
            for (int i = 0; i < ImageSize / 2; i++)
            {
                SynthesisVertical(i, ImageSize / 2);
            }
        }

        private void synHoriz3button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 4;
            for (int i = 0; i < ImageSize / 4; i++)
            {
                SynthesisHorizontal(i, ImageSize / 4);
            }
        }

        private void synVert3button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 4;
            for (int i = 0; i < ImageSize / 4; i++)
            {
                SynthesisVertical(i, ImageSize / 4);
            }
        }

        private void synHoriz4button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 8;
            for (int i = 0; i < ImageSize / 8; i++)
            {
                SynthesisHorizontal(i, ImageSize / 8);
            }
        }

        private void synVert4button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 8;
            for (int i = 0; i < ImageSize / 8; i++)
            {
                SynthesisVertical(i, ImageSize / 8);
            }
        }

        private void synHoriz5button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 16;
            for (int i = 0; i < ImageSize / 16; i++)
            {
                SynthesisHorizontal(i, ImageSize / 16);
            }
        }

        private void synVert5button_Click(object sender, EventArgs e)
        {
            xNumericUpDown.Value = yNumericUpDown.Value = ImageSize / 16;
            for (int i = 0; i < ImageSize / 16; i++)
            {
                SynthesisVertical(i, ImageSize / 16);
            }
        }

        private void anAllButton_Click(object sender, EventArgs e)
        {
            anHoriz1button_Click(sender, e);
            anVert1button_Click(sender, e);
            anHoriz2button_Click(sender, e);
            anVert2button_Click(sender, e);
            anHoriz3button_Click(sender, e);
            anVert3button_Click(sender, e);
            anHoriz4button_Click(sender, e);
            anVert4button_Click(sender, e);
            anHoriz5button_Click(sender, e);
            anVert5button_Click(sender, e);
        }

        private void synAllButton_Click(object sender, EventArgs e)
        {
            synVert5button_Click(sender, e);
            synHoriz5button_Click(sender, e);
            synVert4button_Click(sender, e);
            synHoriz4button_Click(sender, e);
            synVert3button_Click(sender, e);
            synHoriz3button_Click(sender, e);
            synVert2button_Click(sender, e);
            synHoriz2button_Click(sender, e);
            synVert1button_Click(sender, e);
            synHoriz1button_Click(sender, e);        
        }
    }
}
