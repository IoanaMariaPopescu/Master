﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wavelet
{
    public class BitWriter
    {
        byte buffer;
        int counter;
        FileStream fs;
        public BitWriter(string path)
        {
            fs = new FileStream(path, FileMode.Create);
        }

        public void Close()
        {
            for (int i = 1; i <= 7; i++)
            {
                WriteBit(0);
            }

            fs.Close();
        }

        public void WriteBit(uint val)
        {
            buffer <<= 1;
            buffer += (byte)(val & 1);
            counter++;

            if (counter == 8)
            {
                counter = 0;
                fs.WriteByte(buffer);
            }
        }

        public void WriteNBits(uint val, int nr)
        {
            for (int i = nr - 1; i >= 0; i--)
            {
                WriteBit((ushort)(val >> i));
            }
        }
    }
}
