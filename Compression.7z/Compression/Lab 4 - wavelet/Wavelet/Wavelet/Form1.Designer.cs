﻿
namespace Wavelet
{
    partial class WaveletForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.yNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.xNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.offsetNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.scaleNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VisualizeButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.synAllButton = new System.Windows.Forms.Button();
            this.synVert1button = new System.Windows.Forms.Button();
            this.synVert2button = new System.Windows.Forms.Button();
            this.synVert5button = new System.Windows.Forms.Button();
            this.synHoriz1button = new System.Windows.Forms.Button();
            this.synHoriz5button = new System.Windows.Forms.Button();
            this.synHoriz2button = new System.Windows.Forms.Button();
            this.synVert4button = new System.Windows.Forms.Button();
            this.synHoriz3button = new System.Windows.Forms.Button();
            this.synHoriz4button = new System.Windows.Forms.Button();
            this.synVert3button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.anAllButton = new System.Windows.Forms.Button();
            this.anVert1button = new System.Windows.Forms.Button();
            this.anVert5button = new System.Windows.Forms.Button();
            this.anHoriz5button = new System.Windows.Forms.Button();
            this.anVert4button = new System.Windows.Forms.Button();
            this.anHoriz4button = new System.Windows.Forms.Button();
            this.anVert3button = new System.Windows.Forms.Button();
            this.anHoriz3button = new System.Windows.Forms.Button();
            this.anVert2button = new System.Windows.Forms.Button();
            this.anHoriz2button = new System.Windows.Forms.Button();
            this.anHoriz1button = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.maxErrorTextBox = new System.Windows.Forms.TextBox();
            this.minErrorTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.testErrorButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.waveletGroupBox = new System.Windows.Forms.GroupBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.loadWaveletButton = new System.Windows.Forms.Button();
            this.waveletPictureBox = new System.Windows.Forms.PictureBox();
            this.originalGroupBox = new System.Windows.Forms.GroupBox();
            this.loadOriginalButton = new System.Windows.Forms.Button();
            this.originalPictureBox = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.yNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.offsetNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleNumericUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.waveletGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.waveletPictureBox)).BeginInit();
            this.originalGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.yNumericUpDown);
            this.panel1.Controls.Add(this.xNumericUpDown);
            this.panel1.Controls.Add(this.offsetNumericUpDown);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.scaleNumericUpDown);
            this.panel1.Controls.Add(this.VisualizeButton);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1052, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 630);
            this.panel1.TabIndex = 0;
            // 
            // yNumericUpDown
            // 
            this.yNumericUpDown.Location = new System.Drawing.Point(136, 564);
            this.yNumericUpDown.Maximum = new decimal(new int[] {
            511,
            0,
            0,
            0});
            this.yNumericUpDown.Name = "yNumericUpDown";
            this.yNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.yNumericUpDown.TabIndex = 4;
            // 
            // xNumericUpDown
            // 
            this.xNumericUpDown.Location = new System.Drawing.Point(36, 564);
            this.xNumericUpDown.Maximum = new decimal(new int[] {
            511,
            0,
            0,
            0});
            this.xNumericUpDown.Name = "xNumericUpDown";
            this.xNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.xNumericUpDown.TabIndex = 4;
            // 
            // offsetNumericUpDown
            // 
            this.offsetNumericUpDown.Location = new System.Drawing.Point(56, 527);
            this.offsetNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.offsetNumericUpDown.Name = "offsetNumericUpDown";
            this.offsetNumericUpDown.Size = new System.Drawing.Size(74, 20);
            this.offsetNumericUpDown.TabIndex = 4;
            this.offsetNumericUpDown.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 566);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Y:";
            // 
            // scaleNumericUpDown
            // 
            this.scaleNumericUpDown.Location = new System.Drawing.Point(56, 501);
            this.scaleNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.scaleNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.scaleNumericUpDown.Name = "scaleNumericUpDown";
            this.scaleNumericUpDown.Size = new System.Drawing.Size(74, 20);
            this.scaleNumericUpDown.TabIndex = 4;
            this.scaleNumericUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // VisualizeButton
            // 
            this.VisualizeButton.Location = new System.Drawing.Point(39, 595);
            this.VisualizeButton.Name = "VisualizeButton";
            this.VisualizeButton.Size = new System.Drawing.Size(119, 23);
            this.VisualizeButton.TabIndex = 3;
            this.VisualizeButton.Text = "Visualize Wavelet";
            this.VisualizeButton.UseVisualStyleBackColor = true;
            this.VisualizeButton.Click += new System.EventHandler(this.VisualizeButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 566);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "X:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 528);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Offset:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 503);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Scale:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.synAllButton);
            this.groupBox2.Controls.Add(this.synVert1button);
            this.groupBox2.Controls.Add(this.synVert2button);
            this.groupBox2.Controls.Add(this.synVert5button);
            this.groupBox2.Controls.Add(this.synHoriz1button);
            this.groupBox2.Controls.Add(this.synHoriz5button);
            this.groupBox2.Controls.Add(this.synHoriz2button);
            this.groupBox2.Controls.Add(this.synVert4button);
            this.groupBox2.Controls.Add(this.synHoriz3button);
            this.groupBox2.Controls.Add(this.synHoriz4button);
            this.groupBox2.Controls.Add(this.synVert3button);
            this.groupBox2.Location = new System.Drawing.Point(106, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(91, 479);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Synthesis";
            // 
            // synAllButton
            // 
            this.synAllButton.Location = new System.Drawing.Point(10, 439);
            this.synAllButton.Name = "synAllButton";
            this.synAllButton.Size = new System.Drawing.Size(75, 23);
            this.synAllButton.TabIndex = 1;
            this.synAllButton.Text = "All";
            this.synAllButton.UseVisualStyleBackColor = true;
            this.synAllButton.Click += new System.EventHandler(this.synAllButton_Click);
            // 
            // synVert1button
            // 
            this.synVert1button.Location = new System.Drawing.Point(10, 62);
            this.synVert1button.Name = "synVert1button";
            this.synVert1button.Size = new System.Drawing.Size(75, 23);
            this.synVert1button.TabIndex = 0;
            this.synVert1button.Text = "Vertical 1";
            this.synVert1button.UseVisualStyleBackColor = true;
            this.synVert1button.Click += new System.EventHandler(this.synVert1button_Click);
            // 
            // synVert2button
            // 
            this.synVert2button.Location = new System.Drawing.Point(10, 137);
            this.synVert2button.Name = "synVert2button";
            this.synVert2button.Size = new System.Drawing.Size(75, 23);
            this.synVert2button.TabIndex = 0;
            this.synVert2button.Text = "Vertical 2";
            this.synVert2button.UseVisualStyleBackColor = true;
            this.synVert2button.Click += new System.EventHandler(this.synVert2button_Click);
            // 
            // synVert5button
            // 
            this.synVert5button.Location = new System.Drawing.Point(10, 387);
            this.synVert5button.Name = "synVert5button";
            this.synVert5button.Size = new System.Drawing.Size(75, 23);
            this.synVert5button.TabIndex = 0;
            this.synVert5button.Text = "Vertical 5";
            this.synVert5button.UseVisualStyleBackColor = true;
            this.synVert5button.Click += new System.EventHandler(this.synVert5button_Click);
            // 
            // synHoriz1button
            // 
            this.synHoriz1button.Location = new System.Drawing.Point(10, 33);
            this.synHoriz1button.Name = "synHoriz1button";
            this.synHoriz1button.Size = new System.Drawing.Size(75, 23);
            this.synHoriz1button.TabIndex = 0;
            this.synHoriz1button.Text = "Horizontal 1";
            this.synHoriz1button.UseVisualStyleBackColor = true;
            this.synHoriz1button.Click += new System.EventHandler(this.synHoriz1button_Click);
            // 
            // synHoriz5button
            // 
            this.synHoriz5button.Location = new System.Drawing.Point(10, 358);
            this.synHoriz5button.Name = "synHoriz5button";
            this.synHoriz5button.Size = new System.Drawing.Size(75, 23);
            this.synHoriz5button.TabIndex = 0;
            this.synHoriz5button.Text = "Horizontal 5";
            this.synHoriz5button.UseVisualStyleBackColor = true;
            this.synHoriz5button.Click += new System.EventHandler(this.synHoriz5button_Click);
            // 
            // synHoriz2button
            // 
            this.synHoriz2button.Location = new System.Drawing.Point(10, 108);
            this.synHoriz2button.Name = "synHoriz2button";
            this.synHoriz2button.Size = new System.Drawing.Size(75, 23);
            this.synHoriz2button.TabIndex = 0;
            this.synHoriz2button.Text = "Horizontal 2";
            this.synHoriz2button.UseVisualStyleBackColor = true;
            this.synHoriz2button.Click += new System.EventHandler(this.synHoriz2button_Click);
            // 
            // synVert4button
            // 
            this.synVert4button.Location = new System.Drawing.Point(10, 298);
            this.synVert4button.Name = "synVert4button";
            this.synVert4button.Size = new System.Drawing.Size(75, 23);
            this.synVert4button.TabIndex = 0;
            this.synVert4button.Text = "Vertical 4";
            this.synVert4button.UseVisualStyleBackColor = true;
            this.synVert4button.Click += new System.EventHandler(this.synVert4button_Click);
            // 
            // synHoriz3button
            // 
            this.synHoriz3button.Location = new System.Drawing.Point(10, 187);
            this.synHoriz3button.Name = "synHoriz3button";
            this.synHoriz3button.Size = new System.Drawing.Size(75, 23);
            this.synHoriz3button.TabIndex = 0;
            this.synHoriz3button.Text = "Horizontal 3";
            this.synHoriz3button.UseVisualStyleBackColor = true;
            this.synHoriz3button.Click += new System.EventHandler(this.synHoriz3button_Click);
            // 
            // synHoriz4button
            // 
            this.synHoriz4button.Location = new System.Drawing.Point(10, 269);
            this.synHoriz4button.Name = "synHoriz4button";
            this.synHoriz4button.Size = new System.Drawing.Size(75, 23);
            this.synHoriz4button.TabIndex = 0;
            this.synHoriz4button.Text = "Horizontal 4";
            this.synHoriz4button.UseVisualStyleBackColor = true;
            this.synHoriz4button.Click += new System.EventHandler(this.synHoriz4button_Click);
            // 
            // synVert3button
            // 
            this.synVert3button.Location = new System.Drawing.Point(10, 216);
            this.synVert3button.Name = "synVert3button";
            this.synVert3button.Size = new System.Drawing.Size(75, 23);
            this.synVert3button.TabIndex = 0;
            this.synVert3button.Text = "Vertical 3";
            this.synVert3button.UseVisualStyleBackColor = true;
            this.synVert3button.Click += new System.EventHandler(this.synVert3button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.anAllButton);
            this.groupBox1.Controls.Add(this.anVert1button);
            this.groupBox1.Controls.Add(this.anVert5button);
            this.groupBox1.Controls.Add(this.anHoriz5button);
            this.groupBox1.Controls.Add(this.anVert4button);
            this.groupBox1.Controls.Add(this.anHoriz4button);
            this.groupBox1.Controls.Add(this.anVert3button);
            this.groupBox1.Controls.Add(this.anHoriz3button);
            this.groupBox1.Controls.Add(this.anVert2button);
            this.groupBox1.Controls.Add(this.anHoriz2button);
            this.groupBox1.Controls.Add(this.anHoriz1button);
            this.groupBox1.Location = new System.Drawing.Point(6, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(94, 479);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Analysis";
            // 
            // anAllButton
            // 
            this.anAllButton.Location = new System.Drawing.Point(7, 439);
            this.anAllButton.Name = "anAllButton";
            this.anAllButton.Size = new System.Drawing.Size(75, 23);
            this.anAllButton.TabIndex = 1;
            this.anAllButton.Text = "All";
            this.anAllButton.UseVisualStyleBackColor = true;
            this.anAllButton.Click += new System.EventHandler(this.anAllButton_Click);
            // 
            // anVert1button
            // 
            this.anVert1button.Location = new System.Drawing.Point(7, 62);
            this.anVert1button.Name = "anVert1button";
            this.anVert1button.Size = new System.Drawing.Size(75, 23);
            this.anVert1button.TabIndex = 0;
            this.anVert1button.Text = "Vertical 1";
            this.anVert1button.UseVisualStyleBackColor = true;
            this.anVert1button.Click += new System.EventHandler(this.anVert1button_Click);
            // 
            // anVert5button
            // 
            this.anVert5button.Location = new System.Drawing.Point(7, 387);
            this.anVert5button.Name = "anVert5button";
            this.anVert5button.Size = new System.Drawing.Size(75, 23);
            this.anVert5button.TabIndex = 0;
            this.anVert5button.Text = "Vertical 5";
            this.anVert5button.UseVisualStyleBackColor = true;
            this.anVert5button.Click += new System.EventHandler(this.anVert5button_Click);
            // 
            // anHoriz5button
            // 
            this.anHoriz5button.Location = new System.Drawing.Point(7, 358);
            this.anHoriz5button.Name = "anHoriz5button";
            this.anHoriz5button.Size = new System.Drawing.Size(75, 23);
            this.anHoriz5button.TabIndex = 0;
            this.anHoriz5button.Text = "Horizontal 5";
            this.anHoriz5button.UseVisualStyleBackColor = true;
            this.anHoriz5button.Click += new System.EventHandler(this.anHoriz5button_Click);
            // 
            // anVert4button
            // 
            this.anVert4button.Location = new System.Drawing.Point(7, 298);
            this.anVert4button.Name = "anVert4button";
            this.anVert4button.Size = new System.Drawing.Size(75, 23);
            this.anVert4button.TabIndex = 0;
            this.anVert4button.Text = "Vertical 4";
            this.anVert4button.UseVisualStyleBackColor = true;
            this.anVert4button.Click += new System.EventHandler(this.anVert4button_Click);
            // 
            // anHoriz4button
            // 
            this.anHoriz4button.Location = new System.Drawing.Point(7, 269);
            this.anHoriz4button.Name = "anHoriz4button";
            this.anHoriz4button.Size = new System.Drawing.Size(75, 23);
            this.anHoriz4button.TabIndex = 0;
            this.anHoriz4button.Text = "Horizontal 4";
            this.anHoriz4button.UseVisualStyleBackColor = true;
            this.anHoriz4button.Click += new System.EventHandler(this.anHoriz4button_Click);
            // 
            // anVert3button
            // 
            this.anVert3button.Location = new System.Drawing.Point(7, 216);
            this.anVert3button.Name = "anVert3button";
            this.anVert3button.Size = new System.Drawing.Size(75, 23);
            this.anVert3button.TabIndex = 0;
            this.anVert3button.Text = "Vertical 3";
            this.anVert3button.UseVisualStyleBackColor = true;
            this.anVert3button.Click += new System.EventHandler(this.anVert3button_Click);
            // 
            // anHoriz3button
            // 
            this.anHoriz3button.Location = new System.Drawing.Point(7, 187);
            this.anHoriz3button.Name = "anHoriz3button";
            this.anHoriz3button.Size = new System.Drawing.Size(75, 23);
            this.anHoriz3button.TabIndex = 0;
            this.anHoriz3button.Text = "Horizontal 3";
            this.anHoriz3button.UseVisualStyleBackColor = true;
            this.anHoriz3button.Click += new System.EventHandler(this.anHoriz3button_Click);
            // 
            // anVert2button
            // 
            this.anVert2button.Location = new System.Drawing.Point(7, 137);
            this.anVert2button.Name = "anVert2button";
            this.anVert2button.Size = new System.Drawing.Size(75, 23);
            this.anVert2button.TabIndex = 0;
            this.anVert2button.Text = "Vertical 2";
            this.anVert2button.UseVisualStyleBackColor = true;
            this.anVert2button.Click += new System.EventHandler(this.anVert2button_Click);
            // 
            // anHoriz2button
            // 
            this.anHoriz2button.Location = new System.Drawing.Point(7, 108);
            this.anHoriz2button.Name = "anHoriz2button";
            this.anHoriz2button.Size = new System.Drawing.Size(75, 23);
            this.anHoriz2button.TabIndex = 0;
            this.anHoriz2button.Text = "Horizontal 2";
            this.anHoriz2button.UseVisualStyleBackColor = true;
            this.anHoriz2button.Click += new System.EventHandler(this.anHoriz2button_Click);
            // 
            // anHoriz1button
            // 
            this.anHoriz1button.Location = new System.Drawing.Point(7, 33);
            this.anHoriz1button.Name = "anHoriz1button";
            this.anHoriz1button.Size = new System.Drawing.Size(75, 23);
            this.anHoriz1button.TabIndex = 0;
            this.anHoriz1button.Text = "Horizontal 1";
            this.anHoriz1button.UseVisualStyleBackColor = true;
            this.anHoriz1button.Click += new System.EventHandler(this.anHoriz1button_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.maxErrorTextBox);
            this.panel2.Controls.Add(this.minErrorTextBox);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.testErrorButton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 579);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1052, 51);
            this.panel2.TabIndex = 1;
            // 
            // maxErrorTextBox
            // 
            this.maxErrorTextBox.Location = new System.Drawing.Point(167, 28);
            this.maxErrorTextBox.Name = "maxErrorTextBox";
            this.maxErrorTextBox.ReadOnly = true;
            this.maxErrorTextBox.Size = new System.Drawing.Size(496, 20);
            this.maxErrorTextBox.TabIndex = 2;
            this.maxErrorTextBox.WordWrap = false;
            // 
            // minErrorTextBox
            // 
            this.minErrorTextBox.Location = new System.Drawing.Point(167, 4);
            this.minErrorTextBox.Name = "minErrorTextBox";
            this.minErrorTextBox.ReadOnly = true;
            this.minErrorTextBox.Size = new System.Drawing.Size(496, 20);
            this.minErrorTextBox.TabIndex = 2;
            this.minErrorTextBox.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Max:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Min:";
            // 
            // testErrorButton
            // 
            this.testErrorButton.Location = new System.Drawing.Point(12, 16);
            this.testErrorButton.Name = "testErrorButton";
            this.testErrorButton.Size = new System.Drawing.Size(75, 23);
            this.testErrorButton.TabIndex = 0;
            this.testErrorButton.Text = "Test Error";
            this.testErrorButton.UseVisualStyleBackColor = true;
            this.testErrorButton.Click += new System.EventHandler(this.testErrorButton_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.waveletGroupBox);
            this.panel3.Controls.Add(this.originalGroupBox);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1052, 579);
            this.panel3.TabIndex = 2;
            // 
            // waveletGroupBox
            // 
            this.waveletGroupBox.Controls.Add(this.saveButton);
            this.waveletGroupBox.Controls.Add(this.loadWaveletButton);
            this.waveletGroupBox.Controls.Add(this.waveletPictureBox);
            this.waveletGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.waveletGroupBox.Location = new System.Drawing.Point(524, 0);
            this.waveletGroupBox.Name = "waveletGroupBox";
            this.waveletGroupBox.Size = new System.Drawing.Size(528, 579);
            this.waveletGroupBox.TabIndex = 1;
            this.waveletGroupBox.TabStop = false;
            this.waveletGroupBox.Text = "Wavelet Image";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(6, 546);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // loadWaveletButton
            // 
            this.loadWaveletButton.Location = new System.Drawing.Point(87, 546);
            this.loadWaveletButton.Name = "loadWaveletButton";
            this.loadWaveletButton.Size = new System.Drawing.Size(75, 23);
            this.loadWaveletButton.TabIndex = 1;
            this.loadWaveletButton.Text = "Load";
            this.loadWaveletButton.UseVisualStyleBackColor = true;
            this.loadWaveletButton.Click += new System.EventHandler(this.loadWaveletButton_Click);
            // 
            // waveletPictureBox
            // 
            this.waveletPictureBox.Location = new System.Drawing.Point(6, 16);
            this.waveletPictureBox.Name = "waveletPictureBox";
            this.waveletPictureBox.Size = new System.Drawing.Size(512, 512);
            this.waveletPictureBox.TabIndex = 0;
            this.waveletPictureBox.TabStop = false;
            // 
            // originalGroupBox
            // 
            this.originalGroupBox.Controls.Add(this.loadOriginalButton);
            this.originalGroupBox.Controls.Add(this.originalPictureBox);
            this.originalGroupBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.originalGroupBox.Location = new System.Drawing.Point(0, 0);
            this.originalGroupBox.Name = "originalGroupBox";
            this.originalGroupBox.Size = new System.Drawing.Size(524, 579);
            this.originalGroupBox.TabIndex = 0;
            this.originalGroupBox.TabStop = false;
            this.originalGroupBox.Text = "Original Image";
            // 
            // loadOriginalButton
            // 
            this.loadOriginalButton.Location = new System.Drawing.Point(13, 546);
            this.loadOriginalButton.Name = "loadOriginalButton";
            this.loadOriginalButton.Size = new System.Drawing.Size(75, 23);
            this.loadOriginalButton.TabIndex = 1;
            this.loadOriginalButton.Text = "Load";
            this.loadOriginalButton.UseVisualStyleBackColor = true;
            this.loadOriginalButton.Click += new System.EventHandler(this.loadOriginalButton_Click);
            // 
            // originalPictureBox
            // 
            this.originalPictureBox.Location = new System.Drawing.Point(3, 15);
            this.originalPictureBox.Name = "originalPictureBox";
            this.originalPictureBox.Size = new System.Drawing.Size(512, 512);
            this.originalPictureBox.TabIndex = 0;
            this.originalPictureBox.TabStop = false;
            // 
            // WaveletForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 630);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "WaveletForm";
            this.Text = "Wavelet Decomposition";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.yNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.offsetNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleNumericUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.waveletGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.waveletPictureBox)).EndInit();
            this.originalGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.originalPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown yNumericUpDown;
        private System.Windows.Forms.NumericUpDown xNumericUpDown;
        private System.Windows.Forms.NumericUpDown offsetNumericUpDown;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown scaleNumericUpDown;
        private System.Windows.Forms.Button VisualizeButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button synAllButton;
        private System.Windows.Forms.Button synVert1button;
        private System.Windows.Forms.Button synVert2button;
        private System.Windows.Forms.Button synVert5button;
        private System.Windows.Forms.Button synHoriz1button;
        private System.Windows.Forms.Button synHoriz5button;
        private System.Windows.Forms.Button synHoriz2button;
        private System.Windows.Forms.Button synVert4button;
        private System.Windows.Forms.Button synHoriz3button;
        private System.Windows.Forms.Button synHoriz4button;
        private System.Windows.Forms.Button synVert3button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button anAllButton;
        private System.Windows.Forms.Button anVert1button;
        private System.Windows.Forms.Button anVert5button;
        private System.Windows.Forms.Button anHoriz5button;
        private System.Windows.Forms.Button anVert4button;
        private System.Windows.Forms.Button anHoriz4button;
        private System.Windows.Forms.Button anVert3button;
        private System.Windows.Forms.Button anHoriz3button;
        private System.Windows.Forms.Button anVert2button;
        private System.Windows.Forms.Button anHoriz2button;
        private System.Windows.Forms.Button anHoriz1button;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox maxErrorTextBox;
        private System.Windows.Forms.TextBox minErrorTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button testErrorButton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox waveletGroupBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button loadWaveletButton;
        private System.Windows.Forms.PictureBox waveletPictureBox;
        private System.Windows.Forms.GroupBox originalGroupBox;
        private System.Windows.Forms.Button loadOriginalButton;
        private System.Windows.Forms.PictureBox originalPictureBox;
    }
}

